<?php
/* Trang quản lý đề: giáo viên (đề của mình) và quản trị viên (toàn hệ thống). */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
$u = require_user_page();
if (!$u['teacher']) {               // chưa có quyền giáo viên: chuyển sang trang tài khoản
    header('Location: account.php');
    exit;
}
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
readfile(QT_APP . '/views/admin.html');
