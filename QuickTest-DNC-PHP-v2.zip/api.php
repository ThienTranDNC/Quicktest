<?php
/* API thi: POST nội dung JSON {action: exams|start|submit, ...} */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require __DIR__ . '/app/exam.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'Chỉ hỗ trợ POST.'], 405);
same_origin_or_die();
$user = require_user_api();
session_write_close();                       // không giữ khóa phiên trong lúc xử lý
$raw = file_get_contents('php://input');
if (strlen((string)$raw) > 262144) json_out(['ok' => false, 'error' => 'Dữ liệu quá lớn.'], 413);
$p = json_decode((string)$raw, true);
if (!is_array($p)) json_out(['ok' => false, 'error' => 'Dữ liệu gửi lên không hợp lệ.'], 400);
try {
    switch ($p['action'] ?? '') {
        case 'exams': json_out(api_exams($user, $p['key'] ?? ''));
        case 'start': json_out(api_start($user, $p));
        case 'submit': json_out(api_submit($user, $p));
        default: json_out(['ok' => false, 'error' => 'Không rõ yêu cầu.']);
    }
} catch (Throwable $e) {
    error_log('[QuickTest api] ' . $e->getMessage());
    json_out(['ok' => false, 'error' => 'Lỗi máy chủ, vui lòng thử lại.'], 500);
}
