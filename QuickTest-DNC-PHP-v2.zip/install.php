<?php
/* QuickTest DNC – trình cài đặt. Chạy một lần sau khi tải mã nguồn lên hosting, rồi XÓA tệp này. */
declare(strict_types=1);
define('QT_INSTALLER', true);
$appDir = __DIR__ . '/app';
$cfgFile = $appDir . '/config.php';

function ih($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function ipage(string $body): void {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cài đặt QuickTest DNC</title><style>'
        . 'body{margin:0;background:#f4f7fa;color:#14212d;font:17px/1.55 system-ui,"Segoe UI",Roboto,sans-serif}.box{max-width:720px;margin:4vh auto;padding:28px;background:#fff;border:1px solid #d8e1ea;border-radius:14px}'
        . 'h1{font-size:26px;margin:0 0 4px}h2{font-size:19px;margin:22px 0 8px}.logo{display:inline-block;background:#1f7fa6;color:#fff;border-radius:8px;padding:0 10px;margin-right:6px}'
        . 'label{display:block;font-weight:600;font-size:15px;margin-top:10px}input,select{width:100%;padding:10px;border:1px solid #c9d4df;border-radius:8px;font-size:16px;box-sizing:border-box}'
        . '.hint{font-size:14px;color:#5a6b7b}.grid{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}@media(max-width:600px){.grid{grid-template-columns:1fr}}'
        . '.btn{margin-top:20px;width:100%;padding:13px;border:0;border-radius:10px;background:#1f7fa6;color:#fff;font-size:18px;font-weight:600;cursor:pointer}'
        . '.ok{color:#1f7a4d}.bad{color:#b3261e;font-weight:600}.warn{background:#fbefd6;border-left:4px solid #a76a00;padding:10px 14px;border-radius:0 8px 8px 0;margin:12px 0}'
        . 'pre{background:#f1f4f7;padding:12px;border-radius:8px;white-space:pre-wrap;word-break:break-all;font-size:13px}ul{padding-left:20px}a{color:#1f7fa6}'
        . '</style></head><body><div class="box"><h1><span class="logo">QuickTest DNC</span> Cài đặt</h1>' . $body . '</div></body></html>';
    exit;
}

/* ===== Bước 2: đã có tệp cấu hình -> tạo bảng và nạp dữ liệu ban đầu ===== */
if (is_file($cfgFile)) {
    require $appDir . '/bootstrap.php';
    require $appDir . '/schema.php';
    require $appDir . '/io.php';
    try {
        $hasTable = (bool)db()->query("SHOW TABLES LIKE 'qt_questions'")->fetch();
        $nq = $hasTable ? (int)db()->query('SELECT COUNT(*) FROM qt_questions')->fetchColumn() : 0;
        if ($hasTable && $nq > 0) {
            qt_migrate(db(), cfg('admin_emails')[0] ?? 'admin');   // nâng cấp CSDL bản cũ nếu cần
            // Dự phòng: chưa có tài khoản quản trị dùng mật khẩu (ví dụ mất phiên khi cài) thì cho đặt tại đây
            $noPwAdmin = !q1("SELECT 1 FROM qt_users WHERE role = 'admin' AND pass_hash IS NOT NULL");
            $pwErr = '';
            if ($noPwAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
                // Chỉ người nắm mật khẩu CSDL (chủ hosting) mới đặt được mật khẩu quản trị ở bước này
                if (!hash_equals((string)cfg('db_pass'), (string)($_POST['db_pass'] ?? ''))) $pwErr = 'Mật khẩu CSDL không đúng.';
                elseif (strlen((string)($_POST['admin_pass'] ?? '')) < 8) $pwErr = 'Mật khẩu quản trị cần tối thiểu 8 ký tự.';
                elseif (($_POST['admin_pass'] ?? '') !== ($_POST['admin_pass2'] ?? '')) $pwErr = 'Hai lần nhập mật khẩu không khớp.';
            }
            if ($noPwAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && $pwErr === '') {
                $em = cfg('admin_emails')[0] ?? '';
                q("INSERT INTO qt_users (email, name, pass_hash, google, role, teacher_status, created_at) VALUES (?, '', ?, 0, 'admin', 'approved', ?) ON DUPLICATE KEY UPDATE pass_hash = VALUES(pass_hash), role = 'admin', teacher_status = 'approved'",
                  [$em, password_hash((string)$_POST['admin_pass'], PASSWORD_DEFAULT), now_ms()]);
                $noPwAdmin = false;
            }
            if ($noPwAdmin) ipage('<p>Hệ thống đã cài (hoặc vừa nâng cấp lên phiên bản có tài khoản thành viên), nhưng tài khoản quản trị <b>' . ih(cfg('admin_emails')[0] ?? '') . '</b> chưa có mật khẩu.</p>'
                . '<p>Đặt mật khẩu để đăng nhập bằng email (vẫn dùng được nút Google nếu đã cấu hình). Để xác nhận Thầy/Cô là chủ hosting, nhập lại <b>mật khẩu CSDL</b> trong <code>app/config.php</code>.</p>'
                . ($pwErr ? '<p class="bad">' . ih($pwErr) . '</p>' : '')
                . '<form method="post"><label>Mật khẩu CSDL</label><input type="password" name="db_pass" required autocomplete="off"><label>Mật khẩu quản trị mới (tối thiểu 8 ký tự)</label><input type="password" name="admin_pass" required autocomplete="new-password"><label>Nhập lại</label><input type="password" name="admin_pass2" required autocomplete="new-password"><button class="btn">Đặt mật khẩu</button></form>');
            ipage('<p class="ok"><b>Hệ thống đã được cài đặt</b> (' . $nq . ' câu hỏi trong CSDL).</p>'
                . '<div class="warn"><b>Hãy xóa tệp <code>install.php</code></b> trên hosting để bảo mật.</div>'
                . '<ul><li>Trang thi: <a href="index.php">' . ih(cfg('base_url')) . '/</a></li><li>Trang quản trị: <a href="admin.php">' . ih(cfg('base_url')) . '/admin.php</a></li></ul>');
        }
        qt_create_schema(db());
        $owner = cfg('admin_emails')[0] ?? 'admin';
        qt_migrate(db(), $owner);
        // Tài khoản quản trị đầu tiên (mật khẩu đặt ở bước 1, lưu tạm trong phiên cài đặt)
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $adm = $_SESSION['qt_install_admin'] ?? null;
        if ($adm && $adm['email'] === $owner) {
            q("INSERT INTO qt_users (email, name, pass_hash, google, role, teacher_status, created_at) VALUES (?,?,?,0,'admin','approved',?)
               ON DUPLICATE KEY UPDATE name = VALUES(name), pass_hash = VALUES(pass_hash), google = 0, role = 'admin', teacher_status = 'approved'", [$adm['email'], $adm['name'], $adm['hash'], now_ms()]);
            unset($_SESSION['qt_install_admin']);
        }
        $seed = require $appDir . '/seed/seed.php';
        $book = [];
        foreach ($seed as $name => $rows) { $book[$name] = []; foreach ($rows as $i => $cells) $book[$name][] = ['__row' => $i + 1, 'cells' => $cells]; }
        $out = import_book($book, $owner, true);
        if (!$out['ok']) ipage('<p class="bad">Dữ liệu mẫu có lỗi:</p><pre>' . ih(json_encode($out['errors'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) . '</pre>');
        audit('system', 'install', json_encode(['q' => $out['questions'], 'e' => $out['exams']]));
        ipage('<p class="ok"><b>Cài đặt thành công.</b> Đã tạo bảng và nạp ' . $out['questions'] . ' câu hỏi, ' . $out['exams'] . ' đề thi mẫu.</p>'
            . '<div class="warn"><b>Bước cuối: xóa tệp <code>install.php</code></b> trên hosting (qua Trình quản lý tệp của cPanel/DirectAdmin hoặc FTP).</div>'
            . '<ul><li>Trang thi: <a href="index.php">' . ih(cfg('base_url')) . '/</a></li>'
            . '<li>Trang quản lý: <a href="admin.php">' . ih(cfg('base_url')) . '/admin.php</a> – đăng nhập bằng ' . ih($owner) . ' và mật khẩu vừa đặt</li>'
            . '<li>Đăng nhập Google: ' . (google_enabled() ? 'đã bật' : 'chưa bật (điền Client ID/secret trong <code>app/config.php</code> khi có)') . '</li></ul>');
    } catch (Throwable $e) {
        ipage('<p class="bad">Lỗi khi tạo CSDL: ' . ih($e->getMessage()) . '</p><p>Kiểm tra lại thông tin CSDL trong <code>app/config.php</code> rồi tải lại trang này.</p>');
    }
}

/* ===== Bước 1: nhập thông tin, kiểm tra kết nối, ghi tệp cấu hình ===== */
$checks = [
    'PHP 8.0 trở lên (hiện có ' . PHP_VERSION . ')' => version_compare(PHP_VERSION, '8.0.0', '>='),
    'Tiện ích pdo_mysql (kết nối MySQL)' => extension_loaded('pdo_mysql'),
    'Tiện ích zip (đọc/ghi Excel)' => class_exists('ZipArchive'),
    'Tiện ích xmlreader, simplexml (đọc Excel)' => extension_loaded('xmlreader') && extension_loaded('simplexml'),
    'Tiện ích curl (đăng nhập Google)' => extension_loaded('curl'),
    'Tiện ích mbstring (tiếng Việt)' => extension_loaded('mbstring'),
    'Thư mục app/ ghi được (để lưu cấu hình)' => is_writable($appDir),
];
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'https' : 'http';
$dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$guessBase = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $dir;
$v = array_merge(['base_url' => $guessBase, 'db_host' => 'localhost', 'db_port' => '', 'db_name' => '', 'db_user' => '', 'db_pass' => '',
    'google_client_id' => '', 'google_client_secret' => '', 'allowed_domains' => 'nctu.edu.vn', 'admin_email' => '', 'admin_name' => '', 'admin_pass' => '', 'admin_pass2' => '', 'session_hours' => '12'], $_POST);
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v = array_map(fn($x) => trim((string)$x), $v);
    if (!filter_var($v['base_url'], FILTER_VALIDATE_URL)) $err = 'Địa chỉ trang web không hợp lệ.';
    elseif ($v['db_name'] === '' || $v['db_user'] === '') $err = 'Cần nhập tên CSDL và tài khoản CSDL.';
    elseif (!filter_var($v['admin_email'], FILTER_VALIDATE_EMAIL)) $err = 'Email quản trị không hợp lệ.';
    elseif (count(explode(' ', preg_replace('/\s+/u', ' ', $v['admin_name']))) < 2) $err = 'Cần nhập họ và tên quản trị viên.';
    elseif (strlen($v['admin_pass']) < 8) $err = 'Mật khẩu quản trị cần tối thiểu 8 ký tự.';
    elseif ($v['admin_pass'] !== $v['admin_pass2']) $err = 'Hai lần nhập mật khẩu quản trị không khớp.';
    elseif (($v['google_client_id'] === '') !== ($v['google_client_secret'] === '')) $err = 'Đăng nhập Google cần cả Client ID và Client secret (hoặc để trống cả hai).';
    else {
        try {
            $dsn = 'mysql:host=' . $v['db_host'] . ($v['db_port'] !== '' ? ';port=' . (int)$v['db_port'] : '') . ';dbname=' . $v['db_name'] . ';charset=utf8mb4';
            new PDO($dsn, $v['db_user'], $v['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        } catch (Throwable $e) { $err = 'Không kết nối được CSDL: ' . $e->getMessage(); }
    }
    if ($err === '') {
        $cfg = [
            'base_url' => rtrim($v['base_url'], '/'),
            'db_host' => $v['db_host'], 'db_port' => $v['db_port'], 'db_name' => $v['db_name'], 'db_user' => $v['db_user'], 'db_pass' => $v['db_pass'],
            'google_client_id' => $v['google_client_id'], 'google_client_secret' => $v['google_client_secret'],
            'allowed_domains' => $v['allowed_domains'], 'admin_emails' => strtolower($v['admin_email']),
            'session_hours' => max(1, (int)$v['session_hours']),
            'secret' => bin2hex(random_bytes(32)),
        ];
        $php = "<?php\n/* QuickTest DNC – cấu hình (tạo bởi install.php " . date('d/m/Y H:i') . "). Không chia sẻ tệp này. */\nreturn " . var_export($cfg, true) . ";\n";
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        $_SESSION['qt_install_admin'] = ['email' => strtolower($v['admin_email']), 'name' => trim($v['admin_name']), 'hash' => password_hash($v['admin_pass'], PASSWORD_DEFAULT)];
        if (@file_put_contents($cfgFile, $php) !== false) {
            @chmod($cfgFile, 0640);
            header('Location: install.php');
            exit;
        }
        ipage('<p class="bad">Không ghi được tệp <code>app/config.php</code> (thư mục không có quyền ghi).</p>'
            . '<p>Hãy tạo tệp <code>app/config.php</code> bằng Trình quản lý tệp của hosting, dán nội dung dưới đây, lưu lại rồi <a href="install.php">tải lại trang này</a>:</p><pre>' . ih($php) . '</pre>');
    }
}

$rows = '';
$allOk = true;
foreach ($checks as $label => $ok) { $allOk = $allOk && $ok; $rows .= '<li class="' . ($ok ? 'ok' : 'bad') . '">' . ($ok ? '✓ ' : '✗ ') . ih($label) . '</li>'; }
$sel = fn($a, $b) => $a === $b ? ' selected' : '';
ipage(
    '<p>Kiểm tra máy chủ:</p><ul>' . $rows . '</ul>'
    . ($allOk ? '' : '<div class="warn">Có mục chưa đạt. Hãy bật tiện ích PHP tương ứng trong cPanel (Select PHP Version → Extensions) hoặc nhờ nhà cung cấp hosting.</div>')
    . ($err ? '<p class="bad">' . ih($err) . '</p>' : '')
    . '<form method="post">'
    . '<h2>1. Địa chỉ trang web</h2><label>Địa chỉ (không có dấu / ở cuối)</label><input name="base_url" value="' . ih($v['base_url']) . '">'
    . '<div class="hint">Ví dụ: https://quicktest.vn – link và mã QR của đề sẽ dùng địa chỉ này.</div>'
    . '<h2>2. Cơ sở dữ liệu MySQL</h2><div class="hint">Tạo CSDL và tài khoản trong cPanel → MySQL Databases (hoặc DirectAdmin → MySQL Management), gán toàn quyền cho tài khoản.</div>'
    . '<div class="grid"><div><label>Máy chủ CSDL</label><input name="db_host" value="' . ih($v['db_host']) . '"></div><div><label>Cổng (để trống = 3306)</label><input name="db_port" value="' . ih($v['db_port']) . '"></div>'
    . '<div><label>Tên CSDL</label><input name="db_name" value="' . ih($v['db_name']) . '" required></div><div><label>Tài khoản CSDL</label><input name="db_user" value="' . ih($v['db_user']) . '" required></div></div>'
    . '<label>Mật khẩu CSDL</label><input type="password" name="db_pass" value="' . ih($v['db_pass']) . '" autocomplete="new-password">'
    . '<h2>3. Tài khoản quản trị đầu tiên</h2>'
    . '<div class="grid"><div><label>Họ và tên</label><input name="admin_name" value="' . ih($v['admin_name']) . '" required></div>'
    . '<div><label>Email</label><input name="admin_email" type="email" value="' . ih($v['admin_email']) . '" placeholder="tranvanthien@nctu.edu.vn" required></div>'
    . '<div><label>Mật khẩu (tối thiểu 8 ký tự)</label><input type="password" name="admin_pass" autocomplete="new-password" required></div>'
    . '<div><label>Nhập lại mật khẩu</label><input type="password" name="admin_pass2" autocomplete="new-password" required></div></div>'
    . '<h2>4. Đăng nhập bằng Google (không bắt buộc)</h2><div class="hint">Để trống nếu chưa có; thành viên vẫn đăng ký và đăng nhập bằng email + mật khẩu.</div>'
    . '<label>Google Client ID</label><input name="google_client_id" value="' . ih($v['google_client_id']) . '">'
    . '<label>Google Client secret</label><input type="password" name="google_client_secret" value="' . ih($v['google_client_secret']) . '" autocomplete="off">'
    . '<div class="hint">Authorized redirect URI cần khai trên Google Cloud: <b>&lt;địa chỉ trang web&gt;/auth.php?a=callback</b>, ví dụ https://quicktest.vn/auth.php?a=callback</div>'
    . '<div class="grid"><div><label>Miền email dùng nút Google</label><input name="allowed_domains" value="' . ih($v['allowed_domains']) . '"></div>'
    . '<div><label>Số giờ giữ đăng nhập</label><input name="session_hours" value="' . ih($v['session_hours']) . '"></div></div>'
    . '<button class="btn" type="submit">Kiểm tra kết nối và cài đặt</button></form>'
);
