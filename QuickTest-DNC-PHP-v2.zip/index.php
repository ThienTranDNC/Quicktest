<?php
/* Trang thi. Link riêng của đề: index.php?k=<mã> (hoặc /d/<mã> nếu máy chủ hỗ trợ .htaccess) */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require_user_page();
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
readfile(QT_APP . '/views/exam.html');
