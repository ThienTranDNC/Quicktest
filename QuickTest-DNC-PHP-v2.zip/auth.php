<?php
/* Đăng nhập / đăng ký: email + mật khẩu, hoặc Google Workspace. ?a=login|register|google|callback|logout */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';

$a = $_GET['a'] ?? 'login';
$redirectUri = cfg('base_url') . '/auth.php?a=callback';

function auth_page(string $tab, string $err = '', array $v = [], string $info = ''): void {
    $s = settings();
    $next = safe_next($v['next'] ?? ($_GET['next'] ?? ''));
    $g = google_enabled();
    $dom = cfg('allowed_domains');
    $val = fn($k) => h($v[$k] ?? '');
    $gBtn = $g ? '<a class="gbtn" href="auth.php?a=google&amp;next=' . rawurlencode($next) . '"><svg viewBox="0 0 48 48" width="22" height="22" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>'
        . 'Đăng nhập bằng Google' . ($dom ? ' <span>(@' . h($dom[0]) . ')</span>' : '') . '</a><div class="or"><span>hoặc dùng email</span></div>' : '';
    $isReg = $tab === 'register';
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    . '<title>' . ($isReg ? 'Đăng ký' : 'Đăng nhập') . ' – QuickTest DNC</title>'
    . '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%227%22 fill=%22%230b5d7a%22/%3E%3Ctext x=%2216%22 y=%2222%22 font-size=%2216%22 text-anchor=%22middle%22 fill=%22white%22 font-family=%22Arial%22 font-weight=%22bold%22%3EQT%3C/text%3E%3C/svg%3E">'
    . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Lexend:wght@600;700&display=swap">'
    . '<style>
:root{--ink:#122033;--muted:#5b6a7e;--line:#d8e0e8;--bg:#f2f5f8;--card:#fff;--brand:#0b5d7a;--brand2:#0f8a8a;--accent:#f2b544;--err:#b3261e;--errbg:#fbe9e7;--ok:#1f7a4d;--okbg:#e3f3ea;--field:#f7f9fb;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--ink:#e6edf4;--muted:#9cabbc;--line:#2b3b4e;--bg:#0c141e;--card:#131e2b;--brand:#4fb0d0;--brand2:#3cc2b4;--err:#f39a8e;--errbg:#3b1d1a;--ok:#62c995;--okbg:#14301f;--field:#0f1925;color-scheme:dark}}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{font-family:"Be Vietnam Pro",system-ui,"Segoe UI",sans-serif;font-size:17px;line-height:1.5;color:var(--ink);background:var(--bg)}
.wrap{min-height:100%;display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1fr)}
.hero{position:relative;overflow:hidden;color:#fff;padding:56px 56px 48px;display:flex;flex-direction:column;justify-content:space-between;
 background:radial-gradient(1200px 600px at -10% -10%,#1597a8 0%,transparent 60%),radial-gradient(900px 700px at 110% 120%,#f2b544 0%,transparent 55%),linear-gradient(150deg,#08384d 0%,#0b5d7a 55%,#0d6e78 100%)}
.hero .org{font-size:13px;letter-spacing:.12em;text-transform:uppercase;opacity:.85;font-weight:600}
.brand{display:flex;align-items:center;gap:14px;margin-top:18px}
.mark{width:56px;height:56px;border-radius:16px;background:#fff;color:#0b5d7a;display:grid;place-items:center;font:700 22px "Lexend",sans-serif;box-shadow:0 10px 30px rgb(0 0 0 / .25)}
.hero h1{font:700 40px/1.15 "Lexend",sans-serif;margin:26px 0 10px;max-width:15ch}
.hero p.lead{font-size:18px;opacity:.92;max-width:40ch;margin:28px 0 0}
.hero ul{list-style:none;padding:0;margin:30px 0 0;display:grid;gap:14px;max-width:44ch}
.hero li{display:flex;gap:12px;align-items:flex-start;font-size:16px}
.hero li svg{flex:none;margin-top:2px}
.art{margin-top:34px;max-width:420px;opacity:.95}
.foot{font-size:13px;opacity:.75;margin-top:28px}
.side{display:flex;align-items:center;justify-content:center;padding:40px 20px}
.card{width:100%;max-width:440px;background:var(--card);border:1px solid var(--line);border-radius:20px;padding:30px 30px 26px;box-shadow:0 20px 50px rgb(9 30 50 / .08)}
.tabs{display:grid;grid-template-columns:1fr 1fr;background:var(--field);border:1px solid var(--line);border-radius:12px;padding:4px;margin-bottom:22px}
.tabs a{text-align:center;padding:10px;border-radius:9px;color:var(--muted);text-decoration:none;font-weight:600}
.tabs a.on{background:var(--card);color:var(--ink);box-shadow:0 1px 4px rgb(0 0 0 / .08)}
h2{font:700 24px "Lexend",sans-serif;margin:0 0 4px}.sub{color:var(--muted);margin:0 0 18px;font-size:15px}
label{display:block;font-weight:600;font-size:14px;margin:12px 0 6px}
input,select{width:100%;padding:12px 14px;border:1px solid var(--line);border-radius:11px;background:var(--field);color:var(--ink);font:inherit;font-size:16px}
input:focus,select:focus{outline:none;border-color:var(--brand);box-shadow:0 0 0 3px color-mix(in srgb,var(--brand) 22%,transparent)}
.pw{position:relative}.pw button{position:absolute;right:8px;top:50%;transform:translateY(-50%);border:0;background:none;color:var(--muted);font-family:inherit;font-weight:600;font-size:13px;cursor:pointer;padding:6px}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media (max-width:480px){.row2{grid-template-columns:1fr}}
.roles{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:4px}
.roles label{margin:0;display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:12px;padding:12px;cursor:pointer;font-weight:500;background:var(--field)}
.roles input{width:auto;margin-top:3px;accent-color:var(--brand)}
.roles b{display:block;font-size:15px}.roles small{color:var(--muted);font-size:12.5px;line-height:1.35;display:block}
.roles label:has(input:checked){border-color:var(--brand);box-shadow:0 0 0 2px color-mix(in srgb,var(--brand) 25%,transparent)}
.btn{display:block;width:100%;margin-top:20px;padding:14px;border:0;border-radius:12px;background:linear-gradient(135deg,var(--brand),var(--brand2));color:#fff;font-family:inherit;font-weight:600;font-size:17px;cursor:pointer}
.btn:hover{filter:brightness(1.06)}
.gbtn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:12px;border:1px solid var(--line);border-radius:12px;background:var(--card);color:var(--ink);text-decoration:none;font-weight:600}
.gbtn span{color:var(--muted);font-weight:500;font-size:14px}.gbtn:hover{border-color:var(--brand)}
.or{display:flex;align-items:center;gap:12px;color:var(--muted);font-size:13px;margin:18px 0 4px}.or::before,.or::after{content:"";flex:1;height:1px;background:var(--line)}
.msg{padding:11px 13px;border-radius:10px;font-size:15px;margin:0 0 14px}.msg.err{background:var(--errbg);color:var(--err)}.msg.ok{background:var(--okbg);color:var(--ok)}
.hint{font-size:13px;color:var(--muted);margin-top:6px}.small{font-size:14px;color:var(--muted);text-align:center;margin-top:16px}a{color:var(--brand)}
@media (max-width:900px){.wrap{grid-template-columns:1fr}.hero{padding:22px 20px 24px}.hero .art,.hero ul,.hero p.lead,.foot{display:none}.hero h1{font-size:24px;margin:16px 0 0}.side{padding:20px 14px 40px}.card{padding:22px 18px}}
</style></head><body><div class="wrap">'
    . '<section class="hero"><div><div class="org">' . h($s['org_line'] ?? '') . '</div>'
    . '<div class="brand"><div class="mark">QT</div><div><div style="font:700 26px Lexend,sans-serif">QuickTest DNC</div><div style="opacity:.85">' . h($s['app_subtitle'] ?? 'Thi trắc nghiệm trực tuyến') . '</div></div></div>'
    . '<p class="lead">Dành cho giảng viên, cán bộ và sinh viên Trường Đại học Nam Cần Thơ.</p>'
    . '<ul>'
    . '<li><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f2b544" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>Mỗi giáo viên quản lý ngân hàng câu hỏi và đề thi của riêng mình</li>'
    . '<li><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f2b544" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/></svg>Người thi quét mã QR là vào đúng đề, làm được trên điện thoại</li>'
    . '<li><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f2b544" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/></svg>Chấm điểm tự động, thống kê từng câu, xuất kết quả ra Excel</li>'
    . '</ul>'
    . '<svg class="art" viewBox="0 0 420 170" fill="none" aria-hidden="true"><rect x="8" y="14" width="250" height="148" rx="16" fill="#fff" fill-opacity=".1" stroke="#fff" stroke-opacity=".35"/>'
    . '<rect x="28" y="36" width="120" height="10" rx="5" fill="#fff" fill-opacity=".8"/><rect x="28" y="56" width="190" height="8" rx="4" fill="#fff" fill-opacity=".35"/>'
    . '<g><rect x="28" y="78" width="200" height="22" rx="7" fill="#fff" fill-opacity=".14"/><circle cx="40" cy="89" r="5" stroke="#fff" stroke-opacity=".7"/><rect x="52" y="85" width="110" height="7" rx="3.5" fill="#fff" fill-opacity=".5"/></g>'
    . '<g><rect x="28" y="106" width="200" height="22" rx="7" fill="#f2b544" fill-opacity=".9"/><circle cx="40" cy="117" r="5" fill="#08384d"/><rect x="52" y="113" width="130" height="7" rx="3.5" fill="#08384d" fill-opacity=".7"/></g>'
    . '<g><rect x="28" y="134" width="200" height="18" rx="6" fill="#fff" fill-opacity=".14"/></g>'
    . '<rect x="282" y="40" width="112" height="112" rx="14" fill="#fff"/><g fill="#0b5d7a"><rect x="296" y="54" width="26" height="26" rx="3"/><rect x="354" y="54" width="26" height="26" rx="3"/><rect x="296" y="112" width="26" height="26" rx="3"/>'
    . '<rect x="330" y="88" width="10" height="10"/><rect x="344" y="102" width="10" height="10"/><rect x="358" y="88" width="10" height="10"/><rect x="330" y="116" width="10" height="10"/><rect x="368" y="116" width="12" height="12"/><rect x="344" y="128" width="10" height="10"/></g>'
    . '<g fill="#fff"><rect x="302" y="60" width="14" height="14" rx="2"/><rect x="360" y="60" width="14" height="14" rx="2"/><rect x="302" y="118" width="14" height="14" rx="2"/></g></svg>'
    . '</div><div class="foot">© Trường Công nghệ số &amp; Trí tuệ nhân tạo – Trường Đại học Nam Cần Thơ</div></section>'
    . '<section class="side"><div class="card">'
    . '<nav class="tabs"><a href="auth.php?a=login&amp;next=' . rawurlencode($next) . '" class="' . ($isReg ? '' : 'on') . '">Đăng nhập</a><a href="auth.php?a=register&amp;next=' . rawurlencode($next) . '" class="' . ($isReg ? 'on' : '') . '">Đăng ký</a></nav>'
    . ($err ? '<div class="msg err" role="alert">' . h($err) . '</div>' : '') . ($info ? '<div class="msg ok">' . h($info) . '</div>' : '');
    if (!$isReg) {
        echo '<h2>Chào mừng trở lại</h2><p class="sub">Đăng nhập để vào thi hoặc quản lý đề.</p>' . $gBtn
        . '<form method="post" action="auth.php?a=login" novalidate><input type="hidden" name="next" value="' . h($next) . '">'
        . '<label for="em">Email</label><input id="em" name="email" type="email" autocomplete="username" value="' . $val('email') . '" required ' . ($g ? '' : 'autofocus') . '>'
        . '<label for="pw">Mật khẩu</label><div class="pw"><input id="pw" name="password" type="password" autocomplete="current-password" required><button type="button" data-t="pw">Hiện</button></div>'
        . '<button class="btn" type="submit">Đăng nhập</button></form>'
        . '<p class="small">Chưa có tài khoản? <a href="auth.php?a=register&amp;next=' . rawurlencode($next) . '">Đăng ký</a> · Quên mật khẩu? Liên hệ quản trị viên để cấp lại.</p>';
    } else {
        $role = ($v['role'] ?? 'student') === 'teacher' ? 'teacher' : 'student';
        echo '<h2>Tạo tài khoản</h2><p class="sub">Điền thông tin dưới đây. Tài khoản giáo viên cần quản trị viên duyệt.</p>'
        . ($g ? '<div class="hint" style="margin:-6px 0 12px">Email @' . h(implode(', @', $dom)) . ': không cần đăng ký, bấm <b>Đăng nhập bằng Google</b> ở thẻ Đăng nhập.</div>' : '')
        . '<form method="post" action="auth.php?a=register" novalidate><input type="hidden" name="next" value="' . h($next) . '">'
        . '<label for="nm">Họ và tên</label><input id="nm" name="name" autocomplete="name" value="' . $val('name') . '" required autofocus>'
        . '<div class="row2"><div><label for="em">Email</label><input id="em" name="email" type="email" autocomplete="email" value="' . $val('email') . '" required></div>'
        . '<div><label for="un">Đơn vị công tác / Lớp</label><input id="un" name="unit" value="' . $val('unit') . '" placeholder="Khoa, phòng hoặc lớp"></div></div>'
        . '<div class="row2"><div><label for="pw">Mật khẩu</label><div class="pw"><input id="pw" name="password" type="password" autocomplete="new-password" required minlength="8"><button type="button" data-t="pw">Hiện</button></div></div>'
        . '<div><label for="pw2">Nhập lại mật khẩu</label><input id="pw2" name="password2" type="password" autocomplete="new-password" required></div></div>'
        . '<div class="hint">Tối thiểu 8 ký tự, nên có cả chữ và số.</div>'
        . '<label>Vai trò</label><div class="roles">'
        . '<label><input type="radio" name="role" value="student"' . ($role === 'student' ? ' checked' : '') . '><span><b>Người dự thi</b><small>Làm bài thi, xem kết quả của mình</small></span></label>'
        . '<label><input type="radio" name="role" value="teacher"' . ($role === 'teacher' ? ' checked' : '') . '><span><b>Giáo viên</b><small>Ra đề, quản lý câu hỏi và kết quả (cần duyệt)</small></span></label></div>'
        . '<button class="btn" type="submit">Đăng ký</button></form>'
        . '<p class="small">Đã có tài khoản? <a href="auth.php?a=login&amp;next=' . rawurlencode($next) . '">Đăng nhập</a></p>';
    }
    echo '</div></section></div><script>document.querySelectorAll(".pw button").forEach(function(b){b.addEventListener("click",function(){var i=document.getElementById(b.dataset.t);var s=i.type==="password";i.type=s?"text":"password";b.textContent=s?"Ẩn":"Hiện";});});</script></body></html>';
    exit;
}
function after_login(array $u, string $next): void {
    login_user($u);
    $u = user_view($u);
    if ($next === '' || $next === 'index.php') $next = $u['teacher'] ? 'admin.php' : 'index.php';
    header('Location: ' . $next);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') same_origin_or_die();

switch ($a) {
case 'login':
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $info = isset($_GET['info']) ? (string)$_GET['info'] : '';
        auth_page('login', (string)($_GET['err'] ?? ''), [], $info);
    }
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $pw = (string)($_POST['password'] ?? '');
    $next = safe_next($_POST['next'] ?? '');
    $v = ['email' => $email, 'next' => $next];
    if ($email === '' || $pw === '') auth_page('login', 'Vui lòng nhập email và mật khẩu.', $v);
    if (login_blocked($email)) auth_page('login', 'Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút.', $v);
    $u = find_user_by_email($email);
    if ($u && empty($u['pass_hash']) && (int)$u['google']) auth_page('login', 'Tài khoản này đăng nhập bằng Google. Hãy bấm "Đăng nhập bằng Google".', $v);
    if (!$u || empty($u['pass_hash']) || !password_verify($pw, $u['pass_hash'])) { login_failed($email); auth_page('login', 'Email hoặc mật khẩu không đúng.', $v); }
    if (!(int)$u['active']) auth_page('login', 'Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên.', $v);
    if (password_needs_rehash($u['pass_hash'], PASSWORD_DEFAULT)) q('UPDATE qt_users SET pass_hash = ? WHERE id = ?', [password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
    audit($email, 'login');
    after_login($u, $next);

case 'register':
    if ($_SERVER['REQUEST_METHOD'] === 'GET') auth_page('register');
    $v = ['name' => clean_str($_POST['name'] ?? '', 120), 'email' => strtolower(trim((string)($_POST['email'] ?? ''))), 'unit' => clean_str($_POST['unit'] ?? '', 150),
        'role' => ($_POST['role'] ?? '') === 'teacher' ? 'teacher' : 'student', 'next' => safe_next($_POST['next'] ?? '')];
    $pw = (string)($_POST['password'] ?? ''); $pw2 = (string)($_POST['password2'] ?? '');
    if (count(explode(' ', $v['name'])) < 2) auth_page('register', 'Vui lòng nhập đầy đủ họ và tên.', $v);
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL)) auth_page('register', 'Email không hợp lệ.', $v);
    if (must_use_google($v['email'])) auth_page('register', 'Email @' . substr(strrchr($v['email'], '@'), 1) . ' dùng nút "Đăng nhập bằng Google", không cần đăng ký.', $v);
    if (strlen($pw) < 8) auth_page('register', 'Mật khẩu cần tối thiểu 8 ký tự.', $v);
    if ($pw !== $pw2) auth_page('register', 'Hai lần nhập mật khẩu không khớp.', $v);
    if (login_blocked($v['email'])) auth_page('register', 'Thao tác quá nhiều lần. Vui lòng thử lại sau 15 phút.', $v);
    if (find_user_by_email($v['email'])) auth_page('register', 'Email này đã có tài khoản. Hãy đăng nhập.', $v);
    q('INSERT INTO qt_users (email, name, unit, pass_hash, google, role, teacher_status, created_at) VALUES (?,?,?,?,0,?,?,?)',
        [$v['email'], $v['name'], $v['unit'], password_hash($pw, PASSWORD_DEFAULT), 'student', $v['role'] === 'teacher' ? 'pending' : 'none', now_ms()]);
    audit($v['email'], 'register', $v['role'] === 'teacher' ? 'xin quyền giáo viên' : '');
    $u = find_user_by_email($v['email']);
    if ($v['role'] === 'teacher') { login_user($u); header('Location: account.php?welcome=1'); exit; }
    after_login($u, $v['next']);

case 'google':
    if (!google_enabled()) { header('Location: auth.php?a=login'); exit; }
    start_session();
    $_SESSION['oauth'] = ['state' => bin2hex(random_bytes(16)), 'nonce' => bin2hex(random_bytes(16)), 'next' => safe_next($_GET['next'] ?? ''), 'exp' => time() + 600];
    $params = ['client_id' => cfg('google_client_id'), 'redirect_uri' => $redirectUri, 'response_type' => 'code', 'scope' => 'openid email profile',
        'state' => $_SESSION['oauth']['state'], 'nonce' => $_SESSION['oauth']['nonce'], 'prompt' => 'select_account'];
    if (count(cfg('allowed_domains')) === 1) $params['hd'] = cfg('allowed_domains')[0];
    header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params));
    exit;

case 'callback':
    start_session();
    $o = $_SESSION['oauth'] ?? null; unset($_SESSION['oauth']);
    $fail = fn(string $m) => auth_page('login', $m);
    if (isset($_GET['error'])) $fail('Đăng nhập bị hủy.');
    if (!$o || $o['exp'] < time() || !isset($_GET['state']) || !hash_equals($o['state'], (string)$_GET['state'])) $fail('Phiên đăng nhập không hợp lệ, vui lòng thử lại.');
    $ch = curl_init(cfg('google_token_url', 'https://oauth2.googleapis.com/token'));
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
        CURLOPT_POSTFIELDS => http_build_query(['code' => (string)($_GET['code'] ?? ''), 'client_id' => cfg('google_client_id'),
            'client_secret' => cfg('google_client_secret'), 'redirect_uri' => $redirectUri, 'grant_type' => 'authorization_code'])]);
    $body = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch); curl_close($ch);
    if ($body === false) { error_log('[QuickTest] curl: ' . $cerr); $fail('Máy chủ không kết nối được tới Google.'); }
    $tok = json_decode((string)$body, true);
    if ($code !== 200 || empty($tok['id_token'])) $fail('Không xác thực được với Google.');
    // id_token nhận trực tiếp từ máy chủ token của Google qua HTTPS nên được tin cậy; vẫn kiểm tra các trường.
    $parts = explode('.', $tok['id_token']);
    $claims = json_decode(base64_decode(strtr($parts[1] ?? '', '-_', '+/')) ?: '{}', true) ?: [];
    if (!in_array($claims['iss'] ?? '', ['https://accounts.google.com', 'accounts.google.com'], true)) $fail('Mã xác thực không hợp lệ.');
    if (($claims['aud'] ?? '') !== cfg('google_client_id') || (int)($claims['exp'] ?? 0) < time() || ($claims['nonce'] ?? '') !== $o['nonce']) $fail('Mã xác thực không hợp lệ.');
    if (empty($claims['email']) || ($claims['email_verified'] ?? false) !== true) $fail('Tài khoản chưa xác minh email.');
    $email = strtolower($claims['email']);
    $doms = cfg('allowed_domains');
    if ($doms && (empty($claims['hd']) || !in_array(strtolower($claims['hd']), $doms, true) || !domain_allowed($email))) {
        audit($email, 'login_denied', 'hd=' . ($claims['hd'] ?? ''));
        $fail('Nút Google chỉ dành cho tài khoản @' . implode(', @', $doms) . '. Tài khoản khác hãy đăng ký bằng email và mật khẩu.');
    }
    $u = find_user_by_email($email);
    $isCfgAdmin = in_array($email, cfg('admin_emails'), true);
    if (!$u) {
        q('INSERT INTO qt_users (email, name, google, role, teacher_status, created_at) VALUES (?,?,1,?,?,?)',
            [$email, clean_str($claims['name'] ?? '', 120), $isCfgAdmin ? 'admin' : 'student', $isCfgAdmin ? 'approved' : 'none', now_ms()]);
        $u = find_user_by_email($email);
    } else {
        if (!(int)$u['active']) $fail('Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên.');
        $set = ['google = 1']; $args = [];
        if ($u['name'] === '' && !empty($claims['name'])) { $set[] = 'name = ?'; $args[] = clean_str($claims['name'], 120); }
        if ($isCfgAdmin && $u['role'] !== 'admin') { $set[] = "role = 'admin'"; $set[] = "teacher_status = 'approved'"; }
        $args[] = $u['id'];
        q('UPDATE qt_users SET ' . implode(', ', $set) . ' WHERE id = ?', $args);
        $u = find_user_by_email($email);
    }
    audit($email, 'login', 'google');
    after_login($u, $o['next'] ?? '');

case 'logout':
    start_session(); $_SESSION = [];
    setcookie('qt_s', '', ['expires' => time() - 3600, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax']);
    session_destroy();
    header('Location: auth.php?a=login');
    exit;

default:
    http_response_code(404);
}
