<?php
/* API trang quản lý đề: admin_api.php?r=/duong-dan
   - Giáo viên: chỉ thấy và sửa đề, câu hỏi, kết quả của chính mình.
   - Quản trị viên: thấy toàn hệ thống, quản lý thành viên và cài đặt chung. */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
require __DIR__ . '/app/exam.php';
require __DIR__ . '/app/io.php';

same_origin_or_die();
$user = require_staff_api();
session_write_close();

$M = $_SERVER['REQUEST_METHOD'];
$R = '/' . trim((string)($_GET['r'] ?? ''), '/');
$B = in_array($M, ['POST', 'PUT', 'DELETE'], true) && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'json') !== false ? read_json_body() : [];
$ME = $user['email']; $ADMIN = $user['admin'];

function ok_(array $o = []): void { json_out(['ok' => true] + $o); }
function bad_(string $m, int $c = 400): void { json_out(['ok' => false, 'error' => $m], $c); }
function to_ms($v): ?int { if ($v === '' || $v === null) return null; $t = strtotime((string)$v); if ($t === false) throw new RuntimeException('Ngày giờ không hợp lệ: ' . $v); return $t * 1000; }
function b_($v): int { return $v ? 1 : 0; }
function stamp(): string { return date('YmdHi'); }
function admin_only(): void { global $ADMIN; if (!$ADMIN) bad_('Chức năng dành cho quản trị viên.', 403); }
function send_file_and_delete(string $tmp, string $name, string $type): void {
    header('Content-Type: ' . $type);
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . filesize($tmp));
    header('Cache-Control: no-store');
    readfile($tmp); @unlink($tmp); exit;
}
/** Phạm vi xem: giáo viên = chính mình; quản trị viên = ?owner=email (một người) hoặc để trống (tất cả, trả về null). */
function scope_owner(): ?string {
    global $ADMIN, $ME;
    if (!$ADMIN) return $ME;
    $o = strtolower(trim((string)($_GET['owner'] ?? '')));
    return $o === '' || $o === '*' ? null : $o;
}
/** Chủ sở hữu khi tạo / sửa: giáo viên = chính mình; quản trị viên có thể chỉ định người khác. */
function target_owner(array $B = []): string {
    global $ADMIN, $ME;
    if (!$ADMIN) return $ME;
    $o = strtolower(trim((string)($B['owner'] ?? $_GET['owner'] ?? '')));
    return ($o === '' || $o === '*') ? $ME : $o;
}
function can_manage(?array $x): bool { global $ADMIN, $ME; return $x && ($ADMIN || $x['owner'] === $ME); }
function exam_or_404(string $code): array {
    $x = find_exam($code);
    if (!can_manage($x)) bad_('Không tìm thấy đề (hoặc đề không thuộc quyền quản lý của Thầy/Cô).', 404);
    return $x;
}
function result_filter(array $g): array {
    $w = []; $p = [];
    $own = scope_owner();
    if ($own !== null) { $w[] = 'owner = :own'; $p['own'] = $own; }
    if (!empty($g['code'])) { $w[] = 'code = :code'; $p['code'] = $g['code']; }
    if (!empty($g['unit'])) { $w[] = 'unit = :unit'; $p['unit'] = $g['unit']; }
    if (!empty($g['from'])) { $w[] = 'submitted_at >= :f'; $p['f'] = strtotime($g['from']) * 1000; }
    if (!empty($g['to'])) { $w[] = 'submitted_at <= :t'; $p['t'] = strtotime($g['to']) * 1000; }
    if (!empty($g['q'])) { $w[] = '(name LIKE :s1 OR email LIKE :s2 OR unit LIKE :s3)'; $p['s1'] = $p['s2'] = $p['s3'] = '%' . $g['q'] . '%'; }
    return [$w ? ' AND ' . implode(' AND ', $w) : '', $p];
}
function teachers_list(): array {
    return array_map(fn($r) => ['email' => $r['email'], 'name' => $r['name'], 'role' => $r['role']],
        qall("SELECT email, name, role FROM qt_users WHERE role IN ('teacher','admin') ORDER BY name, email"));
}

try {
    /* ---------- Thông tin người đang dùng ---------- */
    if ($M === 'GET' && $R === '/me') {
        $pending = $ADMIN ? (int)q1("SELECT COUNT(*) n FROM qt_users WHERE teacher_status = 'pending' AND role = 'student'")['n'] : 0;
        ok_(['user' => $user + ['roleLabel' => role_label($user['role'])], 'teachers' => $ADMIN ? teachers_list() : [], 'pendingTeachers' => $pending]);
    }

    /* ---------- Tổng quan ---------- */
    if ($M === 'GET' && $R === '/overview') {
        $now = now_ms(); $grace = grace_ms(); $out = []; $own = scope_owner();
        $names = []; foreach (qall('SELECT email, name FROM qt_users') as $u) $names[$u['email']] = $u['name'];
        foreach (all_exams() as $x) {
            if ($own !== null && $x['owner'] !== $own) continue;
            $s = q1('SELECT COUNT(*) n, ROUND(AVG(score),2) avg, SUM(score >= 5) pass FROM qt_attempts WHERE code = ? AND submitted_at IS NOT NULL', [$x['code']]);
            $live = (int)q1('SELECT COUNT(*) n FROM qt_attempts WHERE code = ? AND submitted_at IS NULL AND started_at + minutes*60000 + ? > ?', [$x['code'], $grace, $now])['n'];
            unset($x['access_key']);
            $out[] = $x + ['ownerName' => $names[$x['owner']] ?? '', 'link' => cfg('base_url') . '/?k=' . rawurlencode($x['key']), 'pool' => pool_size($x), 'questions' => count_for($x),
                'open' => is_open($x, $now), 'submitted' => (int)$s['n'], 'avg' => $s['avg'] === null ? null : (float)$s['avg'], 'pass' => (int)$s['pass'], 'live' => $live];
        }
        $qn = $own === null ? q1('SELECT COUNT(*) n, COALESCE(SUM(active),0) a FROM qt_questions') : q1('SELECT COUNT(*) n, COALESCE(SUM(active),0) a FROM qt_questions WHERE owner = ?', [$own]);
        $sub = $own === null ? q1('SELECT COUNT(*) n FROM qt_attempts WHERE submitted_at IS NOT NULL') : q1('SELECT COUNT(*) n FROM qt_attempts WHERE owner = ? AND submitted_at IS NOT NULL', [$own]);
        ok_(['exams' => $out, 'questions' => ['n' => (int)$qn['n'], 'a' => (int)$qn['a']], 'submitted' => (int)$sub['n'], 'serverTime' => gmdate('c'),
            'user' => $user + ['roleLabel' => role_label($user['role'])]]);
    }

    /* ---------- Đề thi ---------- */
    if ($M === 'GET' && $R === '/groups') {
        $owner = target_owner(); $m = [];
        foreach (qall('SELECT groups_, active FROM qt_questions WHERE owner = ?', [$owner]) as $r) foreach (array_filter(array_map('trim', preg_split('/[,;]/', $r['groups_'])), 'strlen') as $g) {
            $m[$g] = $m[$g] ?? ['group' => $g, 'total' => 0, 'active' => 0]; $m[$g]['total']++; $m[$g]['active'] += (int)$r['active'];
        }
        ksort($m); ok_(['groups' => array_values($m), 'owner' => $owner]);
    }
    if (preg_match('#^/exams/([^/]+)$#', $R, $mm) && $M === 'PUT') {
        $code = trim(urldecode($mm[1]));
        if (!preg_match('/^[\w.\-]{2,40}$/', $code)) bad_('Mã đề chỉ gồm chữ, số, dấu gạch; 2–40 ký tự.');
        $old = find_exam($code);
        if ($old && !can_manage($old)) bad_('Mã đề "' . $code . '" đã được giáo viên khác dùng. Hãy đặt mã khác.');
        $owner = $old ? $old['owner'] : target_owner($B);
        $x = ['code' => $code, 'name' => trim((string)($B['name'] ?? '')), 'descr' => trim((string)($B['desc'] ?? '')), 'grp' => trim((string)($B['group'] ?? '')),
            'count' => max(0, (int)($B['count'] ?? 0)), 'minutes' => (int)($B['minutes'] ?? 0), 'open_at' => to_ms($B['openAt'] ?? null), 'close_at' => to_ms($B['closeAt'] ?? null),
            'mode' => trim((string)($B['mode'] ?? 'Thi thử')) ?: 'Thi thử', 'show_answers' => b_($B['showAnswers'] ?? 0), 'retake' => b_($B['retake'] ?? 0),
            'shuffle_q' => b_($B['shuffleQ'] ?? 0), 'shuffle_opts' => b_($B['shuffleOpts'] ?? 0), 'active' => b_($B['active'] ?? 0),
            'sort' => (int)($B['sort'] ?? 0), 'unlisted' => b_($B['unlisted'] ?? 0)];
        if ($x['name'] === '' || $x['grp'] === '') bad_('Cần nhập tên đề và nhóm câu hỏi.');
        if ($x['minutes'] < 1 || $x['minutes'] > 600) bad_('Thời gian làm bài phải từ 1 đến 600 phút.');
        if ($x['open_at'] && $x['close_at'] && $x['open_at'] >= $x['close_at']) bad_('Giờ đóng phải sau giờ mở.');
        upsert_exam($x, $owner); qt_ensure_keys();
        audit($ME, $old ? 'exam_update' : 'exam_create', json_encode($x + ['owner' => $owner], JSON_UNESCAPED_UNICODE));
        $pool = pool_size(find_exam($code));
        ok_(['warning' => $pool === 0 ? 'Nhóm "' . $x['grp'] . '" chưa có câu hỏi đang dùng.' : ($x['count'] > $pool ? "Nhóm chỉ có $pool câu, đề sẽ lấy $pool câu." : '')]);
    }
    if (preg_match('#^/exams/([^/]+)$#', $R, $mm) && $M === 'DELETE') {
        $x = exam_or_404(urldecode($mm[1]));
        $n = (int)q1('SELECT COUNT(*) n FROM qt_attempts WHERE code = ?', [$x['code']])['n'];
        if ($n) bad_("Đề đã có $n lượt thi nên không xóa được. Hãy tắt đề (Đang mở = Không).");
        q('DELETE FROM qt_exams WHERE code = ?', [$x['code']]); audit($ME, 'exam_delete', $x['code']); ok_();
    }
    if (preg_match('#^/exams/([^/]+)/rekey$#', $R, $mm) && $M === 'POST') {
        $x = exam_or_404(urldecode($mm[1]));
        q('UPDATE qt_exams SET access_key = ? WHERE code = ?', [rand_key(), $x['code']]);
        audit($ME, 'exam_rekey', $x['code']);
        ok_(['link' => exam_link(find_exam($x['code']))]);
    }
    if (preg_match('#^/exams/([^/]+)/poster$#', $R, $mm) && $M === 'GET') {
        $x = exam_or_404(urldecode($mm[1]));
        $s = settings(); $link = exam_link($x);
        $when = implode(' · ', array_filter([$x['openAt'] ? 'Mở: ' . fmt_date($x['openAt']) : '', $x['closeAt'] ? 'Đóng: ' . fmt_date($x['closeAt']) : '']));
        $loginHint = google_enabled() && cfg('allowed_domains') ? 'Đăng nhập bằng Google (@' . h(cfg('allowed_domains')[0]) . ') hoặc email đã đăng ký.' : 'Đăng nhập bằng tài khoản đã đăng ký (chưa có thì bấm Đăng ký).';
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>QR – ' . h($x['name']) . '</title><style>'
            . '@page{size:A4;margin:14mm}body{font-family:"Be Vietnam Pro",system-ui,"Segoe UI",sans-serif;color:#111;text-align:center;margin:0;background:#fff}'
            . '.org{font-size:18px;letter-spacing:.04em;text-transform:uppercase;color:#444;margin-top:8px}h1{font-size:40px;margin:14px 0 6px}'
            . '.meta{font-size:22px;color:#333}#qr{width:118mm;height:118mm;margin:16px auto}#qr svg{width:100%;height:100%}'
            . '.link{font-family:Consolas,monospace;font-size:20px;word-break:break-all;border:2px dashed #888;border-radius:10px;padding:10px;margin:8px auto;max-width:170mm}'
            . 'ol{text-align:left;font-size:20px;max-width:165mm;margin:16px auto;line-height:1.5}.noprint{margin:16px}@media print{.noprint{display:none}}button{font-size:18px;padding:8px 18px}'
            . '</style><script src="assets/qrcode.js"></script></head><body>'
            . '<div class="noprint"><button id="p">In trang này</button></div>'
            . '<div class="org">' . h($s['org_line'] ?? '') . '</div><h1>' . h($x['name']) . '</h1>'
            . '<div class="meta">' . h($x['mode']) . ' · ' . count_for($x) . ' câu · ' . $x['minutes'] . ' phút' . ($when ? '<br>' . h($when) : '') . '</div>'
            . '<div id="qr"></div><div class="link">' . h($link) . '</div>'
            . '<ol><li>Quét mã QR bằng camera điện thoại, hoặc gõ đường link trên vào trình duyệt.</li>'
            . '<li>' . $loginHint . '</li>'
            . '<li>Kiểm tra họ tên, nhập đơn vị, chọn đối tượng rồi bấm <b>Bắt đầu làm bài</b>.</li></ol>'
            . '<script>var q=qrcode(0,"M");q.addData(' . json_encode($link) . ');q.make();document.getElementById("qr").innerHTML=q.createSvgTag({cellSize:8,margin:2,scalable:true});'
            . 'document.getElementById("p").onclick=function(){print();};</script></body></html>';
        exit;
    }

    /* ---------- Câu hỏi ---------- */
    if ($M === 'GET' && $R === '/questions') {
        $w = []; $p = []; $own = scope_owner();
        if ($own !== null) { $w[] = 'owner = :own'; $p['own'] = $own; }
        if (!empty($_GET['group'])) { $w[] = "CONCAT(',', REPLACE(groups_, ' ', ''), ',') LIKE :g"; $p['g'] = '%,' . str_replace(' ', '', $_GET['group']) . ',%'; }
        if (!empty($_GET['area'])) { $w[] = 'area = :area'; $p['area'] = $_GET['area']; }
        if (isset($_GET['active']) && ($_GET['active'] === '1' || $_GET['active'] === '0')) { $w[] = 'active = :act'; $p['act'] = (int)$_GET['active']; }
        if (!empty($_GET['q'])) { $w[] = '(id LIKE :q1 OR text LIKE :q2 OR opt_a LIKE :q3 OR opt_b LIKE :q4 OR opt_c LIKE :q5 OR opt_d LIKE :q6)'; foreach (range(1, 6) as $i) $p["q$i"] = '%' . $_GET['q'] . '%'; }
        $rows = qall('SELECT ' . Q_COLS_SQL . ' FROM qt_questions ' . ($w ? 'WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY owner, id', $p);
        $stat = [];
        $sq = 'SELECT t.owner, a.qid, COUNT(*) n, SUM(a.ok) c FROM qt_answers a JOIN qt_attempts t ON t.id = a.attempt_id' . ($own !== null ? ' WHERE t.owner = ?' : '') . ' GROUP BY t.owner, a.qid';
        foreach (qall($sq, $own !== null ? [$own] : []) as $s) $stat[$s['owner'] . '|' . $s['qid']] = $s;
        foreach ($rows as &$r) { $s = $stat[$r['owner'] . '|' . $r['id']] ?? null; $r['active'] = (int)$r['active']; $r['used'] = $s ? (int)$s['n'] : 0; $r['rate'] = $s ? (int)round(100 * $s['c'] / $s['n']) : null; }
        $areas = $own === null ? qall('SELECT DISTINCT area FROM qt_questions ORDER BY area') : qall('SELECT DISTINCT area FROM qt_questions WHERE owner = ? ORDER BY area', [$own]);
        ok_(['questions' => $rows, 'areas' => array_column($areas, 'area')]);
    }
    if (($M === 'POST' && $R === '/questions') || ($M === 'PUT' && preg_match('#^/questions/([^/]+)$#', $R, $mm))) {
        $isNew = $M === 'POST';
        $owner = target_owner($B);
        $id = trim($isNew ? (string)($B['id'] ?? '') : urldecode($mm[1]));
        $qq = ['id' => $id]; foreach (['set_name', 'groups', 'area', 'level', 'text', 'opt_a', 'opt_b', 'opt_c', 'opt_d', 'explain', 'source'] as $k) $qq[$k] = trim((string)($B[$k] ?? ''));
        $qq['answer'] = strtoupper(trim((string)($B['answer'] ?? ''))); $qq['active'] = b_($B['active'] ?? 0);
        if (!preg_match('/^[\w.\-]{1,40}$/', $id)) bad_('Mã câu chỉ gồm chữ, số, dấu gạch.');
        if ($qq['text'] === '' || $qq['opt_a'] === '' || $qq['opt_b'] === '' || $qq['opt_c'] === '' || $qq['opt_d'] === '') bad_('Cần đủ nội dung câu hỏi và 4 phương án.');
        if (!preg_match('/^[ABCD]$/', $qq['answer'])) bad_('Đáp án phải là A, B, C hoặc D.');
        if ($qq['groups'] === '') bad_('Cần ít nhất một nhóm đề.');
        $exists = (bool)q1('SELECT 1 FROM qt_questions WHERE owner = ? AND id = ?', [$owner, $id]);
        if ($isNew && $exists) bad_('Mã câu đã tồn tại trong ngân hàng của Thầy/Cô.');
        if (!$isNew && !$exists) bad_('Không tìm thấy câu hỏi.', 404);
        upsert_question($qq, $owner);
        audit($ME, $isNew ? 'question_create' : 'question_update', json_encode($qq + ['owner' => $owner], JSON_UNESCAPED_UNICODE));
        ok_();
    }
    if ($M === 'DELETE' && preg_match('#^/questions/([^/]+)$#', $R, $mm)) {
        $owner = target_owner(); $id = urldecode($mm[1]);
        if (!q1('SELECT 1 FROM qt_questions WHERE owner = ? AND id = ?', [$owner, $id])) bad_('Không tìm thấy câu hỏi.', 404);
        $n = (int)q1('SELECT COUNT(*) n FROM qt_answers a JOIN qt_attempts t ON t.id = a.attempt_id WHERE t.owner = ? AND a.qid = ?', [$owner, $id])['n'];
        if ($n) bad_("Câu đã xuất hiện trong $n bài làm nên không xóa được. Hãy tắt \"Đang dùng\".");
        q('DELETE FROM qt_questions WHERE owner = ? AND id = ?', [$owner, $id]); audit($ME, 'question_delete', $owner . ' ' . $id); ok_();
    }

    /* ---------- Nhập / xuất Excel ---------- */
    if ($M === 'POST' && $R === '/import') {
        $raw = file_get_contents('php://input');
        if (!$raw) bad_('Chưa có tệp.');
        if (strlen($raw) > 15 * 1048576) bad_('Tệp quá lớn (tối đa 15 MB).');
        $owner = target_owner();
        $tmp = tempnam(sys_get_temp_dir(), 'qti'); file_put_contents($tmp, $raw);
        try { $out = import_workbook($tmp, $owner, ($_GET['exams'] ?? '1') !== '0'); }
        catch (Throwable $e) { @unlink($tmp); bad_('Không đọc được tệp: ' . $e->getMessage()); }
        @unlink($tmp);
        if ($out['ok']) audit($ME, 'import', json_encode(['owner' => $owner, 'q' => $out['questions'], 'e' => $out['exams']]));
        json_out($out);
    }
    if ($M === 'GET' && $R === '/template.xlsx') {
        $tmp = tempnam(sys_get_temp_dir(), 'qtt'); export_template_file($tmp, 'GV' . $user['id']);
        send_file_and_delete($tmp, 'QuickTest_FileMau_NhapDe.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }
    if ($M === 'GET' && $R === '/export/bank.xlsx') {
        @set_time_limit(300);
        $tmp = tempnam(sys_get_temp_dir(), 'qtb'); export_bank_file($tmp, scope_owner());
        send_file_and_delete($tmp, 'QuickTest_NganHang_' . stamp() . '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }
    if ($M === 'GET' && $R === '/export/results.xlsx') {
        @set_time_limit(600); @ini_set('memory_limit', '512M');
        [$w, $p] = result_filter($_GET);
        $tmp = tempnam(sys_get_temp_dir(), 'qtr'); export_results_file($tmp, $w, $p);
        send_file_and_delete($tmp, 'QuickTest_KetQua_' . preg_replace('/[^\w.-]/', '', ($_GET['code'] ?? '') ?: 'TatCa') . '_' . stamp() . '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }

    /* ---------- Kết quả ---------- */
    if ($M === 'GET' && $R === '/results') {
        [$w, $p] = result_filter($_GET);
        $rows = qall("SELECT id, owner, code, email, name, unit, role, started_at, submitted_at, score, correct, total, answered, duration, level, auto_ AS `auto`, late
            FROM qt_attempts WHERE submitted_at IS NOT NULL $w ORDER BY submitted_at DESC LIMIT 2000", $p);
        foreach ($rows as &$r) { foreach (['started_at', 'submitted_at', 'correct', 'total', 'answered', 'duration', 'auto', 'late'] as $k) $r[$k] = (int)$r[$k]; $r['score'] = (float)$r['score']; }
        $own = scope_owner();
        $units = $own === null ? qall('SELECT DISTINCT unit FROM qt_attempts WHERE submitted_at IS NOT NULL ORDER BY unit') : qall('SELECT DISTINCT unit FROM qt_attempts WHERE owner = ? AND submitted_at IS NOT NULL ORDER BY unit', [$own]);
        ok_(['results' => $rows, 'units' => array_column($units, 'unit'), 'truncated' => count($rows) === 2000]);
    }
    if (preg_match('#^/results/([\w-]+)$#', $R, $mm)) {
        $a = q1('SELECT * FROM qt_attempts WHERE id = ?', [$mm[1]]);
        if (!$a || (!$ADMIN && $a['owner'] !== $ME)) bad_('Không tìm thấy.', 404);
        if ($M === 'DELETE') {
            q('DELETE FROM qt_attempts WHERE id = ?', [$a['id']]);
            audit($ME, 'result_delete', json_encode(['id' => $a['id'], 'code' => $a['code'], 'email' => $a['email'], 'score' => $a['score']], JSON_UNESCAPED_UNICODE)); ok_();
        }
        foreach (['started_at', 'submitted_at', 'correct', 'total', 'answered', 'duration'] as $k) $a[$k] = (int)$a[$k];
        $a['score'] = (float)$a['score'];
        $det = qall('SELECT a.pos, a.qid, a.chosen, a.key_ AS `key`, a.ok, a.points, q.text, q.opt_a, q.opt_b, q.opt_c, q.opt_d FROM qt_answers a LEFT JOIN qt_questions q ON q.owner = ? AND q.id = a.qid WHERE a.attempt_id = ? ORDER BY a.pos', [$a['owner'], $a['id']]);
        foreach ($det as &$d) { $d['pos'] = (int)$d['pos']; $d['ok'] = (int)$d['ok']; $d['points'] = (float)$d['points']; $d['text'] = $d['text'] ?? '(câu đã bị xóa)'; $d['options'] = [$d['opt_a'], $d['opt_b'], $d['opt_c'], $d['opt_d']]; }
        ok_(['attempt' => $a, 'answers' => $det]);
    }

    /* ---------- Thống kê ---------- */
    if ($M === 'GET' && $R === '/stats') {
        $w = 't.submitted_at IS NOT NULL'; $p = [];
        $own = scope_owner();
        if ($own !== null) { $w .= ' AND t.owner = :own'; $p['own'] = $own; }
        if (!empty($_GET['code'])) { $w .= ' AND t.code = :code'; $p['code'] = $_GET['code']; }
        $num = fn($v) => $v === null ? null : $v + 0;
        $fix = fn(array $rows) => array_map(fn($r) => array_map(fn($v) => is_string($v) && preg_match('/^-?\d+(\.\d+)?$/', $v) ? $v + 0 : $v, $r), $rows);
        $sum = array_map($num, q1("SELECT COUNT(*) n, COUNT(DISTINCT email) people, ROUND(AVG(score),2) avg, MIN(score) min, MAX(score) max, SUM(score >= 5) pass, ROUND(AVG(duration)) dur FROM qt_attempts t WHERE $w", $p));
        $qj = 'FROM qt_answers a JOIN qt_attempts t ON t.id = a.attempt_id LEFT JOIN qt_questions q ON q.owner = t.owner AND q.id = a.qid';
        ok_(['summary' => $sum,
            'byLevel' => $fix(qall("SELECT level, COUNT(*) n FROM qt_attempts t WHERE $w GROUP BY level", $p)),
            'byUnit' => $fix(qall("SELECT unit, COUNT(*) n, ROUND(AVG(score),2) avg, SUM(score >= 5) pass FROM qt_attempts t WHERE $w GROUP BY unit ORDER BY n DESC", $p)),
            'byRole' => $fix(qall("SELECT role, COUNT(*) n, ROUND(AVG(score),2) avg FROM qt_attempts t WHERE $w GROUP BY role ORDER BY n DESC", $p)),
            'byArea' => $fix(qall("SELECT q.area, COUNT(*) n, SUM(a.ok) c $qj WHERE $w GROUP BY q.area ORDER BY q.area", $p)),
            'perQuestion' => $fix(qall("SELECT a.qid, COUNT(*) n, SUM(a.ok) c, SUM(a.chosen = '') blank, q.text, q.area, q.level, q.answer $qj WHERE $w
                GROUP BY t.owner, a.qid, q.text, q.area, q.level, q.answer ORDER BY (SUM(a.ok) / COUNT(*)) ASC", $p))]);
    }

    /* ---------- Thành viên (quản trị viên) ---------- */
    if ($M === 'GET' && $R === '/users') {
        admin_only();
        $rows = qall("SELECT u.id, u.email, u.name, u.unit, u.role, u.teacher_status, u.active, u.google, (u.pass_hash IS NOT NULL) has_password, u.created_at, u.last_login,
            (SELECT COUNT(*) FROM qt_exams e WHERE e.owner = u.email) exams, (SELECT COUNT(*) FROM qt_questions q WHERE q.owner = u.email) questions
            FROM qt_users u ORDER BY (u.teacher_status = 'pending' AND u.role = 'student') DESC, FIELD(u.role, 'admin', 'teacher', 'student'), u.name, u.email");
        foreach ($rows as &$r) foreach (['id', 'active', 'google', 'has_password', 'created_at', 'last_login', 'exams', 'questions'] as $k) $r[$k] = $r[$k] === null ? null : (int)$r[$k];
        ok_(['users' => $rows, 'cfgAdmins' => cfg('admin_emails')]);
    }
    if ($M === 'PUT' && preg_match('#^/users/(\d+)$#', $R, $mm)) {
        admin_only();
        $u = q1('SELECT * FROM qt_users WHERE id = ?', [(int)$mm[1]]); if (!$u) bad_('Không tìm thấy thành viên.', 404);
        $act = (string)($B['action'] ?? ''); $self = $u['email'] === $ME; $extra = [];
        switch ($act) {
            case 'approve': q("UPDATE qt_users SET role = IF(role = 'admin', 'admin', 'teacher'), teacher_status = 'approved' WHERE id = ?", [$u['id']]); break;
            case 'reject': q("UPDATE qt_users SET teacher_status = 'rejected' WHERE id = ? AND role = 'student'", [$u['id']]); break;
            case 'role':
                $role = (string)($B['role'] ?? '');
                if (!in_array($role, ['student', 'teacher', 'admin'], true)) bad_('Vai trò không hợp lệ.');
                if ($self && $role !== 'admin') bad_('Không tự hạ quyền của chính mình.');
                q('UPDATE qt_users SET role = ?, teacher_status = ? WHERE id = ?', [$role, $role === 'student' ? 'none' : 'approved', $u['id']]);
                if ($role !== 'admin' && in_array($u['email'], cfg('admin_emails'), true)) $extra['warning'] = 'Email này nằm trong admin_emails của app/config.php nên sẽ lại thành quản trị viên khi đăng nhập Google.';
                break;
            case 'deactivate': if ($self) bad_('Không tự khóa tài khoản của chính mình.'); q('UPDATE qt_users SET active = 0 WHERE id = ?', [$u['id']]); break;
            case 'activate': q('UPDATE qt_users SET active = 1 WHERE id = ?', [$u['id']]); break;
            case 'resetpw':
                $tmp = substr(strtr(base64_encode(random_bytes(9)), '+/=', 'xyz'), 0, 10);
                q('UPDATE qt_users SET pass_hash = ? WHERE id = ?', [password_hash($tmp, PASSWORD_DEFAULT), $u['id']]);
                $extra['tempPassword'] = $tmp; break;
            default: bad_('Không rõ thao tác.');
        }
        audit($ME, 'user_' . $act, $u['email'] . (isset($B['role']) ? ' → ' . $B['role'] : ''));
        ok_($extra);
    }

    /* ---------- Cài đặt chung, sao lưu (quản trị viên) ---------- */
    if ($M === 'GET' && $R === '/settings') {
        admin_only();
        ok_(['settings' => settings(), 'googleEnabled' => google_enabled(), 'domains' => cfg('allowed_domains'), 'cfgAdmins' => cfg('admin_emails'),
            'audit' => array_map(fn($r) => ['at' => (int)$r['at'], 'email' => $r['email'], 'action' => $r['action'], 'detail' => $r['detail']], qall('SELECT * FROM qt_audit ORDER BY id DESC LIMIT 100'))]);
    }
    if ($M === 'PUT' && $R === '/settings') {
        admin_only();
        $g = (int)($B['grace_sec'] ?? -1);
        if ($g < 0 || $g > 900) bad_('Thời gian nộp trễ cho phép: 0–900 giây.');
        set_setting('grace_sec', (string)$g);
        foreach (['app_subtitle', 'org_line', 'roles', 'units'] as $k) if (isset($B[$k])) set_setting($k, trim((string)$B[$k]));
        audit($ME, 'settings_update', json_encode($B, JSON_UNESCAPED_UNICODE)); ok_();
    }
    if ($M === 'GET' && $R === '/backup') {
        admin_only();
        @set_time_limit(600);
        audit($ME, 'backup');
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="quicktest_' . stamp() . '.sql"');
        header('Cache-Control: no-store');
        $pdo = db();
        echo "-- QuickTest DNC – bản sao lưu " . date('d/m/Y H:i') . "\n-- Khôi phục: nhập tệp này bằng phpMyAdmin (Import) vào CSDL đã cài QuickTest.\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n";
        foreach (['qt_settings', 'qt_users', 'qt_questions', 'qt_exams', 'qt_attempts', 'qt_answers', 'qt_audit'] as $t) {
            echo "\nDELETE FROM `$t`;\n";
            $st = $pdo->query("SELECT * FROM `$t`");
            $batch = []; $cols = [];
            while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                $cols = array_keys($r);
                $batch[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $r)) . ')';
                if (count($batch) >= 200) { echo "INSERT INTO `$t` (`" . implode('`,`', $cols) . "`) VALUES\n" . implode(",\n", $batch) . ";\n"; $batch = []; }
            }
            if ($batch) echo "INSERT INTO `$t` (`" . implode('`,`', $cols) . "`) VALUES\n" . implode(",\n", $batch) . ";\n";
            flush();
        }
        echo "\nSET FOREIGN_KEY_CHECKS=1;\n";
        exit;
    }
    bad_('Không tìm thấy chức năng: ' . $M . ' ' . $R, 404);
} catch (Throwable $e) {
    error_log('[QuickTest admin] ' . $e->getMessage());
    bad_($e instanceof RuntimeException ? $e->getMessage() : 'Lỗi máy chủ: ' . $e->getMessage(), 500);
}
