<?php
/* QuickTest DNC – bản PHP + MySQL. Khởi tạo chung: cấu hình, kết nối CSDL, phiên đăng nhập, tiện ích. */
declare(strict_types=1);

define('QT_ROOT', dirname(__DIR__));
define('QT_APP', __DIR__);
date_default_timezone_set('Asia/Ho_Chi_Minh');
mb_internal_encoding('UTF-8');

$cfgFile = QT_APP . '/config.php';
if (!is_file($cfgFile)) {
    header('Location: install.php');
    exit;
}
$CFG = require $cfgFile;
$CFG['base_url'] = rtrim((string)$CFG['base_url'], '/');
$CFG['allowed_domains'] = array_values(array_filter(array_map('strtolower', array_map('trim', preg_split('/[,;\s]+/', (string)($CFG['allowed_domains'] ?? ''))))));
$CFG['admin_emails'] = array_values(array_filter(array_map('strtolower', array_map('trim', preg_split('/[,;\s]+/', (string)($CFG['admin_emails'] ?? ''))))));
$CFG['auth_mode'] = strtolower((string)($CFG['auth_mode'] ?? 'google'));
if (!in_array($CFG['auth_mode'], ['google', 'dev'], true)) $CFG['auth_mode'] = 'google';

function cfg(string $k, $def = null) { global $CFG; return $CFG[$k] ?? $def; }

/* ---------- CSDL ---------- */
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host=' . cfg('db_host', 'localhost') . (cfg('db_port') ? ';port=' . cfg('db_port') : '') . ';dbname=' . cfg('db_name') . ';charset=utf8mb4';
    $pdo = new PDO($dsn, cfg('db_user'), cfg('db_pass'), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+07:00'");
    // Tự nâng cấp CSDL khi tải phiên bản mới lên (chỉ chạy khi cần)
    if (!defined('QT_INSTALLER')) {
        try { $ver = (int)($pdo->query("SELECT v FROM qt_settings WHERE k = 'schema_version'")->fetchColumn() ?: 1); }
        catch (Throwable $e) { $ver = 99; }   // chưa cài bảng: để install.php xử lý
        if ($ver < 2) { require_once QT_APP . '/schema.php'; qt_migrate($pdo, cfg('admin_emails')[0] ?? 'admin'); }
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $st = db()->prepare($sql); $st->execute($p); return $st; }
function q1(string $sql, array $p = []) { $r = q($sql, $p)->fetch(); return $r === false ? null : $r; }
function qall(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function now_ms(): int { return (int)floor(microtime(true) * 1000); }

function settings(): array {
    static $s = null;
    if ($s === null) { $s = []; foreach (qall('SELECT k, v FROM qt_settings') as $r) $s[$r['k']] = $r['v']; }
    return $s;
}
function set_setting(string $k, string $v): void {
    q('INSERT INTO qt_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$k, $v]);
}
function audit(string $email, string $action, string $detail = ''): void {
    q('INSERT INTO qt_audit (at, email, action, detail) VALUES (?, ?, ?, ?)', [now_ms(), $email, $action, mb_substr($detail, 0, 2000)]);
}

/* ---------- Phiên đăng nhập ---------- */
function is_https(): bool {
    if (str_starts_with(cfg('base_url'), 'https://')) return true;
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
}
function start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('qt_s');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax']);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.gc_maxlifetime', (string)(((int)cfg('session_hours', 12)) * 3600));
    session_start();
    if (!empty($_SESSION['exp']) && $_SESSION['exp'] < time()) { $_SESSION = []; }
}
/* Vai trò: student (người thi), teacher (giáo viên ra đề), admin (quản trị hệ thống) */
function login_user(array $u): void {
    start_session();
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['exp'] = time() + ((int)cfg('session_hours', 12)) * 3600;
    q('UPDATE qt_users SET last_login = ? WHERE id = ?', [now_ms(), (int)$u['id']]);
}
function user_view(array $r): array {
    $role = $r['role'];
    return ['id' => (int)$r['id'], 'email' => $r['email'], 'name' => $r['name'], 'unit' => $r['unit'], 'role' => $role,
        'teacher_status' => $r['teacher_status'], 'admin' => $role === 'admin', 'teacher' => in_array($role, ['teacher', 'admin'], true),
        'has_password' => !empty($r['pass_hash']), 'google' => (bool)$r['google']];
}
function current_user(): ?array {
    static $cache = false;
    if ($cache !== false) return $cache;
    start_session();
    if (empty($_SESSION['uid'])) return $cache = null;
    $r = q1('SELECT * FROM qt_users WHERE id = ?', [(int)$_SESSION['uid']]);
    if (!$r || !(int)$r['active']) { $_SESSION = []; return $cache = null; }
    return $cache = user_view($r);
}
function find_user_by_email(string $email): ?array { return q1('SELECT * FROM qt_users WHERE email = ?', [strtolower(trim($email))]); }
function google_enabled(): bool { return cfg('google_client_id', '') !== '' && cfg('google_client_secret', '') !== ''; }
/** Email thuộc miền trường (dùng Google) thì không đăng ký bằng mật khẩu, tránh mạo danh. */
function must_use_google(string $email): bool {
    if (!google_enabled() || !cfg('allowed_domains')) return false;
    $d = strtolower(substr(strrchr($email, '@') ?: '', 1));
    return in_array($d, cfg('allowed_domains'), true);
}
function role_label(string $r): string { return ['admin' => 'Quản trị viên', 'teacher' => 'Giáo viên', 'student' => 'Người dự thi'][$r] ?? $r; }
/* Chống dò mật khẩu: tối đa 8 lần sai / 15 phút cho mỗi email.
   Giới hạn theo IP đặt cao (500) vì cả trường có thể ra Internet chung một địa chỉ IP (mạng wifi, NAT). */
function login_blocked(string $email): bool {
    $since = now_ms() - 15 * 60000; $ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64);
    $byEmail = (int)q1('SELECT COUNT(*) n FROM qt_login_attempts WHERE email = ? AND at > ?', [strtolower($email), $since])['n'];
    $byIp = (int)q1('SELECT COUNT(*) n FROM qt_login_attempts WHERE ip = ? AND at > ?', [$ip, $since])['n'];
    return $byEmail >= 8 || $byIp >= 500;
}
function login_failed(string $email): void {
    q('INSERT INTO qt_login_attempts (ip, email, at) VALUES (?, ?, ?)', [substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64), strtolower($email), now_ms()]);
    if (random_int(1, 50) === 1) q('DELETE FROM qt_login_attempts WHERE at < ?', [now_ms() - 86400000]);
}
function domain_allowed(string $email): bool {
    $d = strtolower(substr(strrchr($email, '@') ?: '', 1));
    return !cfg('allowed_domains') || in_array($d, cfg('allowed_domains'), true);
}
/** Đường dẫn nội bộ an toàn để quay lại sau đăng nhập (không cho chuyển sang trang web khác). */
function safe_next(?string $n): string {
    $n = (string)$n;
    if ($n === '' || preg_match('#(^[/\\\\]{2})|:|[\r\n]#', $n) || !preg_match('#^[\w\-./?=&%]*$#', $n)) return 'index.php';
    return ltrim($n, '/') ?: 'index.php';
}
function require_user_page(): array {
    $u = current_user();
    if (!$u) {
        $self = basename($_SERVER['SCRIPT_NAME']) . (empty($_SERVER['QUERY_STRING']) ? '' : '?' . $_SERVER['QUERY_STRING']);
        header('Location: auth.php?a=login&next=' . rawurlencode($self));
        exit;
    }
    return $u;
}
function require_user_api(): array {
    $u = current_user();
    if (!$u) json_out(['ok' => false, 'login' => true, 'error' => 'Phiên đăng nhập đã hết. Vui lòng đăng nhập lại.'], 401);
    return $u;
}
function require_staff_api(): array {
    $u = require_user_api();
    if (!$u['teacher']) json_out(['ok' => false, 'error' => 'Tài khoản chưa có quyền giáo viên.'], 403);
    return $u;
}
/** Chặn yêu cầu ghi gửi từ trang web khác (bổ sung cho cookie SameSite=Lax). */
function same_origin_or_die(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'HEAD') return;
    $o = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($o === '') return;
    $want = parse_url(cfg('base_url'));
    $want = $want['scheme'] . '://' . $want['host'] . (isset($want['port']) ? ':' . $want['port'] : '');
    if (strcasecmp($o, $want) !== 0) json_out(['ok' => false, 'error' => 'Yêu cầu không hợp lệ (khác nguồn).'], 403);
}

/* ---------- Đầu ra ---------- */
function security_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; form-action 'self' https://accounts.google.com");
}
function json_out($o, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function page_html(string $title, string $body): string {
    return '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . h($title) . ' – QuickTest DNC</title><style>'
        . ':root{--bg:#0f1720;--panel:#16212d;--ink:#e8eef4;--muted:#9fb0c0;--brand:#5ab4d6;--line:#26384a;--err:#f08a7e}'
        . '@media (prefers-color-scheme:light){:root{--bg:#f4f7fa;--panel:#fff;--ink:#14212d;--muted:#5a6b7b;--brand:#1f7fa6;--line:#d8e1ea;--err:#b3261e}}'
        . '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:18px/1.55 system-ui,"Segoe UI",Roboto,sans-serif}'
        . '.box{max-width:480px;margin:8vh auto;padding:28px;background:var(--panel);border:1px solid var(--line);border-radius:14px}'
        . 'h1{font-size:24px;margin:0 0 6px}.muted{color:var(--muted);font-size:16px}a{color:var(--brand)}'
        . '.btn{display:flex;align-items:center;justify-content:center;width:100%;padding:13px;border-radius:10px;border:1px solid var(--line);background:var(--brand);color:#04121a;font-weight:600;font-size:18px;text-decoration:none;cursor:pointer}'
        . 'input,select{width:100%;padding:11px;border-radius:9px;border:1px solid var(--line);background:transparent;color:inherit;font-size:17px;margin:4px 0 12px}'
        . 'label{font-weight:600;font-size:15px}.warn{border:1px solid var(--err);color:var(--err);padding:10px;border-radius:9px;font-size:15px;margin:12px 0}.err{color:var(--err)}.ok{color:#3aa76d}'
        . '.logo{display:inline-block;background:var(--brand);color:#04121a;border-radius:8px;padding:0 10px;margin-right:6px;font-weight:700}'
        . 'code,pre{font-family:Consolas,monospace;font-size:14px}pre{white-space:pre-wrap;word-break:break-all;border:1px solid var(--line);padding:10px;border-radius:8px}'
        . '</style></head><body><div class="box">' . $body . '</div></body></html>';
}

/* ---------- Tiện ích ---------- */
function clean_str($s, int $max): string { return mb_substr(trim(preg_replace('/\s+/u', ' ', (string)$s)), 0, $max); }
function rand_key(int $bytes = 9): string { return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '='); }
function uuid4(): string {
    $b = random_bytes(16); $b[6] = chr((ord($b[6]) & 0x0f) | 0x40); $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4));
}
function fmt_date(?int $ms): string { return $ms ? date('d/m/Y H:i', intdiv($ms, 1000)) : ''; }
function exam_link(array $x): string { return cfg('base_url') . '/?k=' . rawurlencode($x['access_key']); }
function read_json_body(): array {
    $raw = file_get_contents('php://input');
    $j = json_decode($raw ?: '{}', true);
    return is_array($j) ? $j : [];
}
security_headers();
