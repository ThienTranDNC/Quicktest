<?php
/* Tạo bảng MySQL / MariaDB. Gọi lại nhiều lần không sao (IF NOT EXISTS). */
declare(strict_types=1);

function qt_create_schema(PDO $pdo): void {
    $opt = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_questions (
        id VARCHAR(40) NOT NULL PRIMARY KEY,
        set_name VARCHAR(40) NOT NULL DEFAULT '',
        groups_ VARCHAR(255) NOT NULL DEFAULT '',
        area VARCHAR(255) NOT NULL DEFAULT '',
        level VARCHAR(40) NOT NULL DEFAULT '',
        text TEXT NOT NULL,
        opt_a TEXT NOT NULL, opt_b TEXT NOT NULL, opt_c TEXT NOT NULL, opt_d TEXT NOT NULL,
        answer CHAR(1) NOT NULL,
        explain_ TEXT NOT NULL,
        source VARCHAR(255) NOT NULL DEFAULT '',
        active TINYINT NOT NULL DEFAULT 1,
        updated_at BIGINT NOT NULL DEFAULT 0
    ) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_exams (
        code VARCHAR(40) NOT NULL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        descr VARCHAR(255) NOT NULL DEFAULT '',
        grp VARCHAR(60) NOT NULL,
        count_ INT NOT NULL DEFAULT 0,
        minutes INT NOT NULL DEFAULT 45,
        open_at BIGINT NULL, close_at BIGINT NULL,
        mode VARCHAR(40) NOT NULL DEFAULT 'Thi thử',
        show_answers TINYINT NOT NULL DEFAULT 1,
        retake TINYINT NOT NULL DEFAULT 1,
        shuffle_q TINYINT NOT NULL DEFAULT 1,
        shuffle_opts TINYINT NOT NULL DEFAULT 1,
        active TINYINT NOT NULL DEFAULT 0,
        sort_ INT NOT NULL DEFAULT 0,
        unlisted TINYINT NOT NULL DEFAULT 0,
        access_key VARCHAR(40) NULL,
        UNIQUE KEY ux_exam_key (access_key)
    ) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_attempts (
        id CHAR(36) NOT NULL PRIMARY KEY,
        code VARCHAR(40) NOT NULL,
        email VARCHAR(190) NOT NULL,
        name VARCHAR(120) NOT NULL,
        unit VARCHAR(150) NOT NULL,
        role VARCHAR(60) NOT NULL DEFAULT '',
        ids MEDIUMTEXT NOT NULL,
        minutes INT NOT NULL,
        started_at BIGINT NOT NULL,
        submitted_at BIGINT NULL,
        score DECIMAL(5,2) NULL, correct INT NULL, total INT NULL, answered INT NULL,
        duration INT NULL, level VARCHAR(20) NULL, auto_ TINYINT NULL, late TINYINT NULL,
        ip VARCHAR(64) NOT NULL DEFAULT '',
        KEY ix_att_code_email (code, email),
        KEY ix_att_sub (submitted_at)
    ) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_answers (
        attempt_id CHAR(36) NOT NULL,
        pos INT NOT NULL,
        qid VARCHAR(40) NOT NULL,
        chosen CHAR(1) NOT NULL DEFAULT '',
        key_ CHAR(1) NOT NULL DEFAULT '',
        ok TINYINT NOT NULL,
        points DECIMAL(6,2) NOT NULL,
        PRIMARY KEY (attempt_id, pos),
        KEY ix_ans_q (qid),
        CONSTRAINT fk_ans_att FOREIGN KEY (attempt_id) REFERENCES qt_attempts(id) ON DELETE CASCADE
    ) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_admins (email VARCHAR(190) NOT NULL PRIMARY KEY, added_by VARCHAR(190), added_at BIGINT) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_settings (k VARCHAR(60) NOT NULL PRIMARY KEY, v TEXT NOT NULL) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_audit (id BIGINT AUTO_INCREMENT PRIMARY KEY, at BIGINT NOT NULL, email VARCHAR(190) NOT NULL, action VARCHAR(60) NOT NULL, detail TEXT NOT NULL, KEY ix_audit_at (at)) $opt");

    $defaults = [
        'grace_sec' => '120',
        'app_subtitle' => 'Thi trắc nghiệm trực tuyến',
        'org_line' => 'Trường Đại học Nam Cần Thơ · Trường Công nghệ số & Trí tuệ nhân tạo',
        'roles' => 'Giảng viên; Cán bộ, nhân viên; Sinh viên',
        'units' => 'Khoa Dược; Khoa Y; Khoa Công nghệ thông tin; Khoa Khoa học máy tính; Trường CNS&TTNT; Phòng Đào tạo; Phòng Tổ chức – Hành chính; Phòng Tài chính – Kế hoạch; Phòng Khảo thí và ĐBCLGD; Phòng Quản trị thiết bị; Phòng Truyền thông; Thư viện',
    ];
    $st = $pdo->prepare('INSERT IGNORE INTO qt_settings (k, v) VALUES (?, ?)');
    foreach ($defaults as $k => $v) $st->execute([$k, $v]);
}

const QT_SCHEMA_VERSION = 2;

/** Nâng cấp CSDL lên phiên bản mới nhất. Chạy được nhiều lần; chỉ làm những bước còn thiếu.
 *  v2: tài khoản thành viên (giáo viên, người thi), mỗi đề / câu hỏi / lượt thi có chủ sở hữu. */
function qt_migrate(PDO $pdo, string $defaultOwner): void {
    $ver = (int)($pdo->query("SELECT v FROM qt_settings WHERE k = 'schema_version'")->fetchColumn() ?: 1);
    if ($ver >= QT_SCHEMA_VERSION) return;
    $opt = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $cols = function (string $t) use ($pdo): array { return array_column($pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_ASSOC), 'Field'); };
    $defaultOwner = strtolower($defaultOwner) ?: 'admin';

    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(190) NOT NULL,
        name VARCHAR(120) NOT NULL DEFAULT '',
        unit VARCHAR(150) NOT NULL DEFAULT '',
        pass_hash VARCHAR(255) NULL,
        google TINYINT NOT NULL DEFAULT 0,
        role VARCHAR(20) NOT NULL DEFAULT 'student',
        teacher_status VARCHAR(20) NOT NULL DEFAULT 'none',
        active TINYINT NOT NULL DEFAULT 1,
        created_at BIGINT NOT NULL DEFAULT 0,
        last_login BIGINT NULL,
        UNIQUE KEY ux_user_email (email)
    ) $opt");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qt_login_attempts (id BIGINT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(64) NOT NULL, email VARCHAR(190) NOT NULL, at BIGINT NOT NULL, KEY ix_la_email (email, at), KEY ix_la_ip (ip, at)) $opt");

    // Câu hỏi: khóa chính (owner, id) để mỗi giáo viên tự đặt mã câu, không đụng nhau
    if (!in_array('owner', $cols('qt_questions'), true)) {
        $pdo->exec("ALTER TABLE qt_questions ADD COLUMN owner VARCHAR(190) NOT NULL DEFAULT '' FIRST");
        $pdo->prepare("UPDATE qt_questions SET owner = ? WHERE owner = ''")->execute([$defaultOwner]);
        $pdo->exec("ALTER TABLE qt_questions DROP PRIMARY KEY, ADD PRIMARY KEY (owner, id)");
    }
    if (!in_array('owner', $cols('qt_exams'), true)) {
        $pdo->exec("ALTER TABLE qt_exams ADD COLUMN owner VARCHAR(190) NOT NULL DEFAULT '', ADD KEY ix_exam_owner (owner)");
        $pdo->prepare("UPDATE qt_exams SET owner = ? WHERE owner = ''")->execute([$defaultOwner]);
    }
    if (!in_array('owner', $cols('qt_attempts'), true)) {
        $pdo->exec("ALTER TABLE qt_attempts ADD COLUMN owner VARCHAR(190) NOT NULL DEFAULT '', ADD KEY ix_att_owner (owner, submitted_at)");
        $pdo->exec("UPDATE qt_attempts t JOIN qt_exams e ON e.code = t.code SET t.owner = e.owner");
        $pdo->prepare("UPDATE qt_attempts SET owner = ? WHERE owner = ''")->execute([$defaultOwner]);
    }
    // Quản trị viên của bản cũ trở thành tài khoản quản trị (đăng nhập bằng Google như trước)
    $ins = $pdo->prepare("INSERT IGNORE INTO qt_users (email, name, google, role, teacher_status, created_at) VALUES (?, '', 1, 'admin', 'approved', ?)");
    $now = (int)floor(microtime(true) * 1000);
    if ($defaultOwner !== 'admin') $ins->execute([$defaultOwner, $now]);
    if ($pdo->query("SHOW TABLES LIKE 'qt_admins'")->fetch()) foreach ($pdo->query('SELECT email FROM qt_admins')->fetchAll(PDO::FETCH_COLUMN) as $e) $ins->execute([strtolower($e), $now]);

    $pdo->prepare("INSERT INTO qt_settings (k, v) VALUES ('schema_version', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)")->execute([(string)QT_SCHEMA_VERSION]);
}

function qt_ensure_keys(): void {
    foreach (qall('SELECT code FROM qt_exams WHERE access_key IS NULL') as $r) {
        q('UPDATE qt_exams SET access_key = ? WHERE code = ?', [rand_key(), $r['code']]);
    }
}
