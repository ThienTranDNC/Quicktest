<?php
/* Nghiệp vụ thi: danh sách đề, phát đề, chấm điểm. Đáp án không gửi xuống trình duyệt trước khi nộp. */
declare(strict_types=1);

const Q_COLS_SQL = "owner, id, set_name, groups_ AS `groups`, area, level, text, opt_a, opt_b, opt_c, opt_d, answer, explain_ AS `explain`, source, active, updated_at";

function q_row(array $r): array {
    return [
            'id' => $r['id'],
            'groups' => array_values(array_filter(array_map('trim', preg_split('/[,;]/', $r['groups'])), 'strlen')),
            'area' => $r['area'], 'level' => $r['level'], 'text' => $r['text'],
            'options' => [$r['opt_a'], $r['opt_b'], $r['opt_c'], $r['opt_d']],
            'a' => strpos('ABCD', $r['answer']) === false ? -1 : strpos('ABCD', $r['answer']),
            'e' => $r['explain'], 's' => $r['source'],
        ];
}
/** Chỉ đọc những câu cần thiết để giảm tải khi đông người thi. */
function questions_by_ids(string $owner, array $ids): array {
    if (!$ids) return [];
    $B = [];
    foreach (array_chunk(array_values(array_unique($ids)), 500) as $chunk) {
        foreach (qall('SELECT ' . Q_COLS_SQL . ' FROM qt_questions WHERE owner = ? AND active = 1 AND id IN (' . implode(',', array_fill(0, count($chunk), '?')) . ')', array_merge([$owner], $chunk)) as $r) $B[$r['id']] = q_row($r);
    }
    return $B;
}
const GROUP_MATCH_SQL = "CONCAT(',', REPLACE(REPLACE(groups_, ' ', ''), ';', ','), ',') LIKE ?";
function group_like(string $g): string { return '%,' . str_replace([' ', '%', '_'], ['', '\\%', '\\_'], $g) . ',%'; }

function row_to_exam(array $r): array {
    return [
        'code' => $r['code'], 'name' => $r['name'], 'desc' => $r['descr'], 'group' => $r['grp'],
        'count' => (int)$r['count_'], 'minutes' => (int)$r['minutes'],
        'openAt' => $r['open_at'] === null ? null : (int)$r['open_at'],
        'closeAt' => $r['close_at'] === null ? null : (int)$r['close_at'],
        'mode' => $r['mode'], 'showAnswers' => (bool)$r['show_answers'], 'retake' => (bool)$r['retake'],
        'shuffleQ' => (bool)$r['shuffle_q'], 'shuffleOpts' => (bool)$r['shuffle_opts'], 'active' => (bool)$r['active'],
        'sort' => (int)$r['sort_'], 'unlisted' => (bool)$r['unlisted'], 'key' => (string)$r['access_key'],
        'access_key' => (string)$r['access_key'], 'owner' => (string)$r['owner'],
    ];
}
function all_exams(): array { return array_map('row_to_exam', qall('SELECT * FROM qt_exams ORDER BY sort_, code')); }
function find_exam($code): ?array { $r = q1('SELECT * FROM qt_exams WHERE code = ?', [(string)$code]); return $r ? row_to_exam($r) : null; }
function find_by_key($key): ?array {
    $key = (string)$key; if ($key === '') return null;
    $r = q1('SELECT * FROM qt_exams WHERE access_key = ?', [$key]); return $r ? row_to_exam($r) : null;
}
function is_open(array $x, int $now): bool {
    return $x['active'] && (!$x['openAt'] || $now >= $x['openAt']) && (!$x['closeAt'] || $now <= $x['closeAt']);
}
function pool_for(array $x): array {
    $out = [];
    foreach (qall('SELECT ' . Q_COLS_SQL . ' FROM qt_questions WHERE owner = ? AND active = 1 AND ' . GROUP_MATCH_SQL, [$x['owner'], group_like($x['group'])]) as $r) {
        $q = q_row($r); if (in_array($x['group'], $q['groups'], true) && $q['a'] >= 0) $out[] = $q;
    }
    return $out;
}
function pool_size(array $x): int { return (int)q1("SELECT COUNT(*) n FROM qt_questions WHERE owner = ? AND active = 1 AND answer IN ('A','B','C','D') AND " . GROUP_MATCH_SQL, [$x['owner'], group_like($x['group'])])['n']; }
function count_for(array $x): int { $n = pool_size($x); return ($x['count'] && $x['count'] < $n) ? $x['count'] : $n; }
function level_of(float $sc): string { return $sc >= 8.5 ? 'Tốt' : ($sc >= 7 ? 'Khá' : ($sc >= 5 ? 'Đạt' : 'Chưa đạt')); }
function shuffled(array $a): array { for ($i = count($a) - 1; $i > 0; $i--) { $j = random_int(0, $i); [$a[$i], $a[$j]] = [$a[$j], $a[$i]]; } return $a; }
function token_for(string $id): string { return rtrim(strtr(base64_encode(hash_hmac('sha256', 'attempt:' . $id, cfg('secret'), true)), '+/', '-_'), '='); }
function grace_ms(): int { return ((int)(settings()['grace_sec'] ?? 120)) * 1000; }
function has_submitted(string $code, string $email): bool {
    return (bool)q1('SELECT 1 FROM qt_attempts WHERE code = ? AND email = ? AND submitted_at IS NOT NULL LIMIT 1', [$code, $email]);
}
function split_list(string $s): array { return array_values(array_filter(array_map('trim', explode(';', $s)), 'strlen')); }

/* ---------- API ---------- */
function api_exams(array $user, $key): array {
    $now = now_ms(); $s = settings();
    $linked = find_by_key($key);
    $exams = [];
    // Chỉ vào thi bằng link/QR: trang thi không liệt kê đề; chỉ trả về đúng đề của đường link hợp lệ.
    foreach (($linked ? [$linked] : []) as $x) {
        if (!is_open($x, $now)) continue;
        $exams[] = ['code' => $x['code'], 'name' => $x['name'], 'desc' => $x['desc'], 'minutes' => $x['minutes'], 'mode' => $x['mode'],
            'count' => count_for($x), 'closeAt' => $x['closeAt'] ? gmdate('c', intdiv($x['closeAt'], 1000)) : '',
            'done' => !$x['retake'] && has_submitted($x['code'], $user['email'])];
    }
    $focus = ''; $note = '';
    if ((string)$key !== '') {
        if (!$linked) $note = 'Đường link không hợp lệ hoặc đã được thay mới. Vui lòng lấy link mới từ Ban Tổ chức.';
        elseif (!is_open($linked, $now)) $note = '"' . $linked['name'] . '" ' . ($linked['openAt'] && $now < $linked['openAt'] ? 'chưa đến giờ mở (mở lúc ' . fmt_date($linked['openAt']) . ').' : 'hiện không mở.');
        else $focus = $linked['code'];
    }
    return ['ok' => true, 'exams' => $exams, 'focus' => $focus, 'linkNote' => $note, 'needLink' => (string)$key === '', 'email' => $user['email'], 'displayName' => $user['name'], 'unit' => $user['unit'], 'teacher' => $user['teacher'],
        'admin' => $user['admin'], 'serverTime' => gmdate('c'), 'orgLine' => $s['org_line'] ?? '', 'subtitle' => $s['app_subtitle'] ?? '',
        'roles' => split_list($s['roles'] ?? ''), 'units' => split_list($s['units'] ?? '')];
}

function start_payload(array $exam, array $row, array $questions, int $now): array {
    $ids = json_decode($row['ids'], true);
    return [
        'ok' => true, 'token' => token_for($row['id']),
        'attempt' => ['id' => $row['id'], 'code' => $row['code'], 'name' => $row['name'], 'unit' => $row['unit'], 'role' => $row['role'],
            'email' => $row['email'], 'ids' => $ids, 'startedAt' => (int)$row['started_at'], 'minutes' => (int)$row['minutes']],
        'remainingSec' => max(0, (int)round(((int)$row['started_at'] + (int)$row['minutes'] * 60000 - $now) / 1000)),
        'exam' => ['code' => $exam['code'], 'name' => $exam['name'], 'minutes' => $exam['minutes'], 'mode' => $exam['mode'], 'shuffleOpts' => $exam['shuffleOpts']],
        'questions' => array_map(fn($q) => ['id' => $q['id'], 'area' => $q['area'], 'level' => $q['level'], 'text' => $q['text'], 'options' => $q['options']], $questions),
        'serverTime' => gmdate('c'),
    ];
}

function api_start(array $user, array $p): array {
    $name = clean_str($p['name'] ?? '', 80); $unit = clean_str($p['unit'] ?? '', 100); $role = clean_str($p['role'] ?? '', 40);
    if (count(explode(' ', $name)) < 2) return ['ok' => false, 'error' => 'Vui lòng nhập đầy đủ họ và tên.'];
    if (mb_strlen($unit) < 2) return ['ok' => false, 'error' => 'Vui lòng nhập đơn vị công tác / lớp.'];
    $exam = find_exam($p['code'] ?? '');
    $now = now_ms();
    if (!$exam || !is_open($exam, $now)) return ['ok' => false, 'error' => 'Đề thi này hiện không mở.'];
    if ((string)($p['key'] ?? '') === '' || !hash_equals($exam['key'], (string)$p['key'])) return ['ok' => false, 'error' => 'Đề này chỉ vào được bằng đường link hoặc mã QR do Ban Tổ chức cung cấp.'];
    if (!$exam['retake']) {
        if (has_submitted($exam['code'], $user['email'])) return ['ok' => false, 'error' => 'Tài khoản ' . $user['email'] . ' đã nộp bài đề này. Đề không cho phép làm lại.'];
        // Đang có lượt dở dang còn hạn: trả lại đúng lượt đó (cùng câu hỏi, cùng giờ bắt đầu)
        $open = q1('SELECT * FROM qt_attempts WHERE code = ? AND email = ? AND submitted_at IS NULL AND started_at + minutes * 60000 + ? > ? ORDER BY started_at DESC LIMIT 1',
            [$exam['code'], $user['email'], grace_ms(), $now]);
        if ($open) {
            $oids = json_decode($open['ids'], true); $B = questions_by_ids($exam['owner'], $oids);
            $qs = array_values(array_filter(array_map(fn($id) => $B[$id] ?? null, $oids)));
            return start_payload($exam, $open, $qs, $now) + ['resumed' => true];
        }
    }
    $pool = pool_for($exam);
    if (!$pool) return ['ok' => false, 'error' => 'Đề chưa có câu hỏi. Vui lòng báo Ban Tổ chức.'];
    $picked = ($exam['count'] && $exam['count'] < count($pool)) ? array_slice(shuffled($pool), 0, $exam['count']) : $pool;
    if ($exam['shuffleQ']) $picked = shuffled($picked);
    $row = ['id' => uuid4(), 'owner' => $exam['owner'], 'code' => $exam['code'], 'email' => $user['email'], 'name' => $name, 'unit' => $unit, 'role' => $role,
        'ids' => json_encode(array_map(fn($q) => $q['id'], $picked)), 'minutes' => $exam['minutes'], 'started_at' => $now,
        'ip' => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64)];
    q('INSERT INTO qt_attempts (id, owner, code, email, name, unit, role, ids, minutes, started_at, ip) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        [$row['id'], $row['owner'], $row['code'], $row['email'], $row['name'], $row['unit'], $row['role'], $row['ids'], $row['minutes'], $row['started_at'], $row['ip']]);
    return start_payload($exam, $row, $picked, $now);
}

function result_of(array $row, ?array $exam): array {
    $out = ['ok' => true, 'score' => (float)$row['score'], 'correct' => (int)$row['correct'], 'total' => (int)$row['total'], 'answered' => (int)$row['answered'],
        'durationSec' => (int)$row['duration'], 'level' => $row['level'], 'late' => (bool)$row['late'], 'showReview' => (bool)($exam && $exam['showAnswers'])];
    if ($out['showReview']) {
        $ans = qall('SELECT * FROM qt_answers WHERE attempt_id = ? ORDER BY pos', [$row['id']]);
        $B = questions_by_ids((string)$row['owner'], array_column($ans, 'qid')); $out['review'] = [];
        foreach ($ans as $a) {
            $qq = $B[$a['qid']] ?? null;
            $out['review'][] = ['id' => $a['qid'], 'chosen' => $a['chosen'] === '' ? null : strpos('ABCD', $a['chosen']),
                'answer' => $a['key_'] === '' ? null : strpos('ABCD', $a['key_']), 'ok' => (int)$a['ok'], 'explain' => $qq['e'] ?? '', 'source' => $qq['s'] ?? ''];
        }
    }
    return $out;
}

function api_submit(array $user, array $p): array {
    $id = (string)($p['attempt']['id'] ?? '');
    $token = (string)($p['token'] ?? '');
    if ($id === '' || !hash_equals(token_for($id), $token)) return ['ok' => false, 'error' => 'Mã lượt thi không hợp lệ.'];
    $row = q1('SELECT * FROM qt_attempts WHERE id = ?', [$id]);
    if (!$row) return ['ok' => false, 'error' => 'Không tìm thấy lượt thi.'];
    if ($row['email'] !== $user['email']) return ['ok' => false, 'error' => 'Lượt thi này thuộc tài khoản khác (' . $row['email'] . ').'];
    $exam = find_exam($row['code']);
    if ($row['submitted_at'] !== null) return result_of($row, $exam);   // nộp lặp lại: trả kết quả cũ

    $now = now_ms();
    $started = (int)$row['started_at']; $limit = $started + (int)$row['minutes'] * 60000;
    $late = $now > $limit + grace_ms();
    $endAt = min($now, $limit);
    $ids = json_decode($row['ids'], true);
    $answers = is_array($p['answers'] ?? null) ? $p['answers'] : [];
    $B = questions_by_ids((string)$row['owner'], $ids); $pts = 10 / count($ids); $correct = 0; $answered = 0; $detail = [];
    foreach ($ids as $i => $qid) {
        $qq = $B[$qid] ?? null;
        $c = $answers[$qid] ?? null;
        $c = (is_int($c) && $c >= 0 && $c <= 3) ? $c : null;
        if ($c !== null) $answered++;
        $ok = ($c !== null && $qq && $c === $qq['a']) ? 1 : 0;
        if ($late) $ok = 0;
        $correct += $ok;
        $detail[] = [$i + 1, $qid, $c === null ? '' : 'ABCD'[$c], ($qq && $qq['a'] >= 0) ? 'ABCD'[$qq['a']] : '', $ok, round($ok * $pts, 2)];
    }
    $score = round($correct * $pts, 2);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('UPDATE qt_attempts SET submitted_at = ?, score = ?, correct = ?, total = ?, answered = ?, duration = ?, level = ?, auto_ = ?, late = ? WHERE id = ? AND submitted_at IS NULL');
        $st->execute([$now, $score, $correct, count($ids), $answered, (int)round(($endAt - $started) / 1000), level_of($score), empty($p['auto']) ? 0 : 1, $late ? 1 : 0, $id]);
        if ($st->rowCount() === 1) {
            $vals = []; $args = [];
            foreach ($detail as $d) { $vals[] = '(?,?,?,?,?,?,?)'; array_push($args, $id, ...$d); }
            $pdo->prepare('INSERT INTO qt_answers (attempt_id, pos, qid, chosen, key_, ok, points) VALUES ' . implode(',', $vals))->execute($args);
        }
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
    return result_of(q1('SELECT * FROM qt_attempts WHERE id = ?', [$id]), $exam);
}
