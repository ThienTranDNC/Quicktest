<?php
/* Đọc / ghi tệp Excel .xlsx tối giản, chỉ cần PHP ZipArchive + SimpleXML (không cần thư viện ngoài). */
declare(strict_types=1);

/** Đọc toàn bộ tệp: trả về [tên trang => [[ô,...], ...]] (dòng đầu là tiêu đề). */
function xlsx_read(string $file): array {
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) throw new RuntimeException('Không mở được tệp Excel (.xlsx).');
    $shared = [];
    if (($x = $zip->getFromName('xl/sharedStrings.xml')) !== false) {
        $sx = simplexml_load_string($x);
        foreach ($sx->si as $si) {
            if (isset($si->t)) { $shared[] = (string)$si->t; continue; }
            $s = ''; foreach ($si->r as $r) $s .= (string)$r->t; $shared[] = $s;
        }
    }
    $rels = [];
    $rx = simplexml_load_string($zip->getFromName('xl/_rels/workbook.xml.rels') ?: '<Relationships/>');
    foreach ($rx->Relationship as $r) $rels[(string)$r['Id']] = (string)$r['Target'];
    $wb = simplexml_load_string($zip->getFromName('xl/workbook.xml') ?: '');
    if (!$wb) throw new RuntimeException('Tệp Excel không hợp lệ.');
    $wb->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
    $out = [];
    foreach ($wb->sheets->sheet as $sh) {
        $rid = (string)$sh->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
        $target = $rels[$rid] ?? '';
        $path = str_starts_with($target, '/') ? ltrim($target, '/') : 'xl/' . $target;
        $xml = $zip->getFromName($path);
        if ($xml === false) continue;
        $out[(string)$sh['name']] = xlsx_sheet_rows($xml, $shared);
    }
    $zip->close();
    return $out;
}
function xlsx_col_index(string $ref): int {
    preg_match('/^([A-Z]+)/', $ref, $m); $n = 0;
    foreach (str_split($m[1] ?? 'A') as $ch) $n = $n * 26 + (ord($ch) - 64);
    return $n - 1;
}
function xlsx_sheet_rows(string $xml, array $shared): array {
    $rows = [];
    $r = new XMLReader(); $r->XML($xml);
    $cur = null; $col = 0; $type = ''; $val = null; $inV = false; $inIs = false; $rowNum = 0;
    while ($r->read()) {
        if ($r->nodeType === XMLReader::ELEMENT) {
            switch ($r->localName) {
                case 'row': $rowNum = (int)$r->getAttribute('r'); $cur = []; break;
                case 'c': $col = $r->getAttribute('r') ? xlsx_col_index($r->getAttribute('r')) : count($cur); $type = (string)$r->getAttribute('t'); $val = ''; break;
                case 'v': $inV = true; break;
                case 'is': $inIs = true; break;
                case 't': if ($inIs) { $val .= $r->readString(); } break;
            }
        } elseif ($r->nodeType === XMLReader::TEXT || $r->nodeType === XMLReader::CDATA) {
            if ($inV) $val .= $r->value;
        } elseif ($r->nodeType === XMLReader::END_ELEMENT) {
            switch ($r->localName) {
                case 'v': $inV = false; break;
                case 'is': $inIs = false; break;
                case 'c':
                    if ($type === 's') $v = $shared[(int)$val] ?? '';
                    elseif ($type === 'b') $v = $val === '1' ? 'TRUE' : 'FALSE';
                    elseif ($type === 'inlineStr' || $type === 'str' || $type === 'e') $v = (string)$val;
                    else $v = $val === '' ? '' : (is_numeric($val) ? $val + 0 : $val);
                    $cur[$col] = $v; break;
                case 'row':
                    if ($cur) { $max = max(array_keys($cur)); $line = []; for ($i = 0; $i <= $max; $i++) $line[] = $cur[$i] ?? ''; $rows[] = ['__row' => $rowNum, 'cells' => $line]; }
                    $cur = null; break;
            }
        }
    }
    return $rows;
}

/* ---------- Ghi ---------- */
function xlsx_cell_ref(int $c, int $r): string { $s = ''; $c++; while ($c > 0) { $m = ($c - 1) % 26; $s = chr(65 + $m) . $s; $c = intdiv($c - 1, 26); } return $s . $r; }
function xlsx_esc(string $s): string { return htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s), ENT_XML1 | ENT_QUOTES, 'UTF-8'); }

/** Ghi tệp xlsx. $sheets = [tên => ['rows' => iterable các dòng, 'widths' => [..]]]. Dòng đầu in đậm, cố định. */
function xlsx_write(string $file, array $sheets): void {
    $zip = new ZipArchive();
    if ($zip->open($file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new RuntimeException('Không tạo được tệp.');
    $tmpFiles = [];
    $n = 0; $sheetXml = ''; $relXml = ''; $ctXml = '';
    foreach ($sheets as $name => $def) {
        $n++;
        $tmp = tempnam(sys_get_temp_dir(), 'qtx'); $tmpFiles[] = $tmp;
        $fh = fopen($tmp, 'w');
        fwrite($fh, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>');
        if (!empty($def['widths'])) {
            fwrite($fh, '<cols>');
            foreach ($def['widths'] as $i => $w) fwrite($fh, '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $w . '" customWidth="1"/>');
            fwrite($fh, '</cols>');
        }
        fwrite($fh, '<sheetData>');
        $r = 0;
        foreach ($def['rows'] as $row) {
            $r++;
            $buf = '<row r="' . $r . '">';
            foreach (array_values($row) as $c => $v) {
                $ref = xlsx_cell_ref($c, $r); $st = $r === 1 ? ' s="1"' : '';
                if ($v === null || $v === '') continue;
                if ((is_int($v) || is_float($v)) && is_finite((float)$v)) $buf .= '<c r="' . $ref . '"' . $st . '><v>' . $v . '</v></c>';
                else $buf .= '<c r="' . $ref . '" t="inlineStr"' . $st . '><is><t xml:space="preserve">' . xlsx_esc((string)$v) . '</t></is></c>';
            }
            fwrite($fh, $buf . '</row>');
        }
        fwrite($fh, '</sheetData></worksheet>');
        fclose($fh);
        $zip->addFile($tmp, "xl/worksheets/sheet$n.xml");
        $sheetXml .= '<sheet name="' . xlsx_esc((string)$name) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
        $relXml .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
        $ctXml .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
    }
    $relXml .= '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' . $ctXml . '</Types>');
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $sheetXml . '</sheets></workbook>');
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $relXml . '</Relationships>');
    $zip->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
        . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDCEAF2"/><bgColor indexed="64"/></patternFill></fill></fills>'
        . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
        . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
    $zip->close();
    foreach ($tmpFiles as $t) @unlink($t);
}
