<?php
/* Nhập / xuất Excel cùng định dạng với bản Node.js và bản Google Sheets. */
declare(strict_types=1);
require_once __DIR__ . '/xlsx.php';
require_once __DIR__ . '/schema.php';

const QT_Q_COLS = ['MaCau', 'Bo', 'De', 'Mang', 'MucDo', 'CauHoi', 'A', 'B', 'C', 'D', 'DapAn', 'GiaiThich', 'CanCu', 'DangDung'];
const QT_E_COLS = ['MaDe', 'TenDe', 'MoTa', 'NhomCau', 'SoCau', 'ThoiGianPhut', 'MoLuc', 'DongLuc', 'CheDo', 'HienDapAn', 'ChoLamLai', 'TronCau', 'TronPhuongAn', 'DangMo', 'ChiVaoBangLink'];

function yes_v($v): bool { return (bool)preg_match('/^(c[oó]|x|yes|true|1)$/iu', trim((string)$v)); }
function no_v($v): bool { return (bool)preg_match('/^(kh[oô]ng|no|false|0)$/iu', trim((string)$v)); }
function yn(bool $b): string { return $b ? 'Có' : 'Không'; }

/** "dd/mm/yyyy hh:mm" (giờ Việt Nam) hoặc số ngày kiểu Excel -> mốc ms */
function parse_vn_date($v): ?int {
    if ($v === '' || $v === null) return null;
    if (is_int($v) || is_float($v)) return (int)round(((float)$v - 25569) * 86400000) - 7 * 3600000;
    if (!preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?$#', trim((string)$v), $m)) throw new RuntimeException('Ngày giờ "' . $v . '" không đúng dạng dd/mm/yyyy hh:mm');
    $dt = new DateTime(sprintf('%04d-%02d-%02d %02d:%02d:00', $m[3], $m[2], $m[1], $m[4] ?? 0, $m[5] ?? 0), new DateTimeZone('Asia/Ho_Chi_Minh'));
    return $dt->getTimestamp() * 1000;
}
function rows_to_assoc(array $rows): array {
    if (!$rows) return [[], []];
    $head = array_map(fn($h) => trim((string)$h), $rows[0]['cells']);
    $out = [];
    foreach (array_slice($rows, 1) as $r) {
        $o = ['__row' => $r['__row']];
        foreach ($head as $i => $h) if ($h !== '') $o[$h] = $r['cells'][$i] ?? '';
        $out[] = $o;
    }
    return [$head, $out];
}

/** Nhập tệp. Không ghi gì nếu có lỗi; trả về danh sách lỗi theo dòng. */
function import_workbook(string $file, string $owner, bool $withExams = true): array { return import_book(xlsx_read($file), $owner, $withExams); }
/** $book = [tên trang => [['__row' => số dòng, 'cells' => [...]], ...]] */
function import_book(array $book, string $owner, bool $withExams = true): array {
    if (!$book) throw new RuntimeException('Tệp không có trang tính nào.');
    $qName = isset($book['CauHoi']) ? 'CauHoi' : array_key_first($book);
    [$head, $rows] = rows_to_assoc($book[$qName]);
    $missing = array_diff(array_slice(QT_Q_COLS, 0, 11), $head);
    if ($missing) throw new RuntimeException('Trang "' . $qName . '" thiếu cột: ' . implode(', ', $missing));
    $errors = []; $qs = []; $seen = [];
    foreach ($rows as $o) {
        $s = fn($k) => trim((string)($o[$k] ?? ''));
        if ($s('MaCau') === '' && $s('CauHoi') === '') continue;
        $q = ['id' => $s('MaCau'), 'set_name' => $s('Bo'), 'groups' => $s('De'), 'area' => $s('Mang'), 'level' => $s('MucDo'), 'text' => $s('CauHoi'),
            'opt_a' => $s('A'), 'opt_b' => $s('B'), 'opt_c' => $s('C'), 'opt_d' => $s('D'), 'answer' => strtoupper($s('DapAn')),
            'explain' => $s('GiaiThich'), 'source' => $s('CanCu'), 'active' => no_v($o['DangDung'] ?? '') ? 0 : 1];
        $e = [];
        if ($q['id'] === '') $e[] = 'thiếu MaCau';
        elseif (!preg_match('/^[\w.\-]{1,40}$/u', $q['id'])) $e[] = 'MaCau chỉ gồm chữ, số, dấu gạch';
        if ($q['text'] === '') $e[] = 'thiếu nội dung câu hỏi';
        if ($q['opt_a'] === '' || $q['opt_b'] === '' || $q['opt_c'] === '' || $q['opt_d'] === '') $e[] = 'thiếu phương án';
        if (!preg_match('/^[ABCD]$/', $q['answer'])) $e[] = 'DapAn phải là A, B, C hoặc D';
        if ($q['groups'] === '') $e[] = 'thiếu cột De (nhóm đề)';
        if (count(array_unique(array_map('mb_strtolower', [$q['opt_a'], $q['opt_b'], $q['opt_c'], $q['opt_d']]))) < 4) $e[] = 'có phương án trùng nhau';
        if (isset($seen[$q['id']])) $e[] = 'MaCau bị trùng trong tệp';
        $seen[$q['id']] = 1;
        if ($e) $errors[] = ['sheet' => $qName, 'row' => $o['__row'], 'id' => $q['id'], 'error' => implode('; ', $e)];
        else $qs[] = $q;
    }
    $es = [];
    if ($withExams && isset($book['DeThi'])) {
        [, $erows] = rows_to_assoc($book['DeThi']);
        foreach ($erows as $i => $o) {
            $s = fn($k) => trim((string)($o[$k] ?? ''));
            if ($s('MaDe') === '') continue;
            try {
                $x = ['code' => $s('MaDe'), 'name' => $s('TenDe'), 'descr' => $s('MoTa'), 'grp' => $s('NhomCau'), 'count' => (int)$s('SoCau'),
                    'minutes' => ((int)$s('ThoiGianPhut')) ?: 45, 'open_at' => parse_vn_date($o['MoLuc'] ?? ''), 'close_at' => parse_vn_date($o['DongLuc'] ?? ''),
                    'mode' => $s('CheDo') ?: 'Thi thử', 'show_answers' => (int)yes_v($o['HienDapAn'] ?? ''), 'retake' => (int)yes_v($o['ChoLamLai'] ?? ''),
                    'shuffle_q' => (int)yes_v($o['TronCau'] ?? ''), 'shuffle_opts' => (int)yes_v($o['TronPhuongAn'] ?? ''), 'active' => (int)yes_v($o['DangMo'] ?? ''),
                    'sort' => $i, 'unlisted' => (int)yes_v($o['ChiVaoBangLink'] ?? '')];
                $taken = $x['code'] !== '' ? q1('SELECT owner FROM qt_exams WHERE code = ?', [$x['code']]) : null;
                if ($x['code'] === '' || $x['name'] === '' || $x['grp'] === '') $errors[] = ['sheet' => 'DeThi', 'row' => $o['__row'], 'id' => $x['code'], 'error' => 'thiếu MaDe, TenDe hoặc NhomCau'];
                elseif (!preg_match('/^[\w.\-]{2,40}$/', $x['code'])) $errors[] = ['sheet' => 'DeThi', 'row' => $o['__row'], 'id' => $x['code'], 'error' => 'MaDe chỉ gồm chữ, số, dấu gạch; 2–40 ký tự'];
                elseif ($taken && $taken['owner'] !== $owner) $errors[] = ['sheet' => 'DeThi', 'row' => $o['__row'], 'id' => $x['code'], 'error' => 'mã đề đã được giáo viên khác dùng, hãy đặt mã khác'];
                else $es[] = $x;
            } catch (Throwable $err) { $errors[] = ['sheet' => 'DeThi', 'row' => $o['__row'], 'id' => $s('MaDe'), 'error' => $err->getMessage()]; }
        }
    }
    if ($errors) return ['ok' => false, 'errors' => $errors, 'questions' => 0, 'exams' => 0];
    $before = array_flip(array_column(qall('SELECT id FROM qt_questions WHERE owner = ?', [$owner]), 'id'));
    $pdo = db(); $pdo->beginTransaction();
    try {
        foreach ($qs as $qq) upsert_question($qq, $owner);
        foreach ($es as $x) upsert_exam($x, $owner, false);
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
    qt_ensure_keys();
    return ['ok' => true, 'errors' => [], 'questions' => count($qs), 'added' => count(array_filter($qs, fn($qq) => !isset($before[$qq['id']]))), 'exams' => count($es)];
}

function upsert_question(array $q, string $owner): void {
    q('INSERT INTO qt_questions (owner, id, set_name, groups_, area, level, text, opt_a, opt_b, opt_c, opt_d, answer, explain_, source, active, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE set_name=VALUES(set_name), groups_=VALUES(groups_), area=VALUES(area), level=VALUES(level), text=VALUES(text),
       opt_a=VALUES(opt_a), opt_b=VALUES(opt_b), opt_c=VALUES(opt_c), opt_d=VALUES(opt_d), answer=VALUES(answer), explain_=VALUES(explain_),
       source=VALUES(source), active=VALUES(active), updated_at=VALUES(updated_at)',
      [$owner, $q['id'], $q['set_name'], $q['groups'], $q['area'], $q['level'], $q['text'], $q['opt_a'], $q['opt_b'], $q['opt_c'], $q['opt_d'],
       $q['answer'], $q['explain'], $q['source'], $q['active'], now_ms()]);
}
function upsert_exam(array $x, string $owner, bool $withSort = true): void {
    q('INSERT INTO qt_exams (owner, code, name, descr, grp, count_, minutes, open_at, close_at, mode, show_answers, retake, shuffle_q, shuffle_opts, active, sort_, unlisted)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE name=VALUES(name), descr=VALUES(descr), grp=VALUES(grp), count_=VALUES(count_), minutes=VALUES(minutes),
       open_at=VALUES(open_at), close_at=VALUES(close_at), mode=VALUES(mode), show_answers=VALUES(show_answers), retake=VALUES(retake),
       shuffle_q=VALUES(shuffle_q), shuffle_opts=VALUES(shuffle_opts), active=VALUES(active), unlisted=VALUES(unlisted)' . ($withSort ? ', sort_=VALUES(sort_)' : ''),
      [$owner, $x['code'], $x['name'], $x['descr'], $x['grp'], $x['count'], $x['minutes'], $x['open_at'], $x['close_at'], $x['mode'],
       $x['show_answers'], $x['retake'], $x['shuffle_q'], $x['shuffle_opts'], $x['active'], $x['sort'], $x['unlisted']]);
}

/** $owner = null: xuất toàn hệ thống (quản trị viên) */
function export_bank_file(string $file, ?string $owner): void {
    $q = function () use ($owner) {
        yield QT_Q_COLS;
        $st = db()->prepare('SELECT * FROM qt_questions' . ($owner === null ? '' : ' WHERE owner = ?') . ' ORDER BY owner, id'); $st->execute($owner === null ? [] : [$owner]);
        while ($r = $st->fetch()) yield [$r['id'], $r['set_name'], $r['groups_'], $r['area'], $r['level'], $r['text'], $r['opt_a'], $r['opt_b'], $r['opt_c'], $r['opt_d'], $r['answer'], $r['explain_'], $r['source'], yn((bool)$r['active'])];
    };
    $e = function () use ($owner) {
        yield QT_E_COLS;
        foreach (qall('SELECT * FROM qt_exams' . ($owner === null ? '' : ' WHERE owner = ?') . ' ORDER BY sort_, code', $owner === null ? [] : [$owner]) as $r) yield [$r['code'], $r['name'], $r['descr'], $r['grp'], $r['count_'] ? (int)$r['count_'] : '', (int)$r['minutes'],
            fmt_date($r['open_at'] === null ? null : (int)$r['open_at']), fmt_date($r['close_at'] === null ? null : (int)$r['close_at']), $r['mode'],
            yn((bool)$r['show_answers']), yn((bool)$r['retake']), yn((bool)$r['shuffle_q']), yn((bool)$r['shuffle_opts']), yn((bool)$r['active']), yn((bool)$r['unlisted'])];
    };
    xlsx_write($file, ['CauHoi' => ['rows' => $q(), 'widths' => [16, 8, 12, 30, 12, 60, 40, 40, 40, 40, 8, 30, 24, 10]], 'DeThi' => ['rows' => $e(), 'widths' => [12, 30, 24, 10, 8, 12, 17, 17, 12, 10, 10, 10, 12, 10, 14]]]);
}

function export_results_file(string $file, string $where, array $params): void {
    $res = function () use ($where, $params) {
        yield ['ThoiDiemNop', 'MaLuot', 'MaDe', 'HoTen', 'DonVi', 'DoiTuong', 'Email', 'Diem', 'SoCauDung', 'TongSoCau', 'SoCauDaLam', 'ThoiGianGiay', 'ThoiGianLam', 'XepLoai', 'TuNopKhiHetGio', 'BatDauLuc', 'GhiChu'];
        $st = db()->prepare("SELECT * FROM qt_attempts WHERE submitted_at IS NOT NULL $where ORDER BY submitted_at"); $st->execute($params);
        while ($r = $st->fetch()) {
            $d = (int)$r['duration'];
            yield [fmt_date((int)$r['submitted_at']), $r['id'], $r['code'], $r['name'], $r['unit'], $r['role'], $r['email'], (float)$r['score'], (int)$r['correct'], (int)$r['total'],
                (int)$r['answered'], $d, sprintf('%02d:%02d', intdiv($d, 60), $d % 60), $r['level'], yn((bool)$r['auto_']), fmt_date((int)$r['started_at']), $r['late'] ? 'Nộp quá hạn' : ''];
        }
    };
    $det = function () use ($where, $params) {
        yield ['MaLuot', 'MaDe', 'HoTen', 'DonVi', 'Email', 'STT', 'MaCau', 'Chon', 'DapAn', 'Dung', 'Diem'];
        $w = str_replace(['owner =', 'code =', 'unit =', 'submitted_at >=', 'submitted_at <=', '(name LIKE', 'email LIKE', 'unit LIKE'],
                         ['t.owner =', 't.code =', 't.unit =', 't.submitted_at >=', 't.submitted_at <=', '(t.name LIKE', 't.email LIKE', 't.unit LIKE'], $where);
        $st = db()->prepare("SELECT t.id, t.code, t.name, t.unit, t.email, a.pos, a.qid, a.chosen, a.key_, a.ok, a.points FROM qt_attempts t JOIN qt_answers a ON a.attempt_id = t.id
            WHERE t.submitted_at IS NOT NULL $w ORDER BY t.submitted_at, a.pos");
        $st->execute($params);
        while ($r = $st->fetch(PDO::FETCH_NUM)) { $r[5] = (int)$r[5]; $r[9] = (int)$r[9]; $r[10] = (float)$r[10]; yield $r; }
    };
    xlsx_write($file, ['KetQua' => ['rows' => $res(), 'widths' => [17, 38, 12, 26, 26, 16, 30, 7, 10, 10, 10, 12, 11, 10, 14, 17, 12]], 'ChiTiet' => ['rows' => $det()]]);
}

/** File mẫu để giáo viên soạn câu hỏi và đề rồi nhập vào hệ thống. */
/** $prefix: tiền tố riêng của giáo viên cho mã đề ví dụ (mã đề phải không trùng trên toàn hệ thống). */
function export_template_file(string $file, string $prefix = 'GV'): void {
    $q = [QT_Q_COLS,
        ['TH-001', '2026', 'GK1', 'Chương 1 – Khái niệm', 'Dễ', 'Thiết bị nào sau đây là thiết bị nhập?', 'Màn hình', 'Bàn phím', 'Loa', 'Máy in', 'B', 'Bàn phím dùng để nhập dữ liệu vào máy tính.', 'Giáo trình chương 1', 'Có'],
        ['TH-002', '2026', 'GK1, CK', 'Chương 1 – Khái niệm', 'Trung bình', '1 byte bằng bao nhiêu bit?', '4 bit', '8 bit', '16 bit', '32 bit', 'B', '', 'Giáo trình chương 1', 'Có'],
        ['TH-003', '2026', 'CK', 'Chương 2 – Ứng dụng', 'Khó', 'Phím tắt nào dùng để sao chép trong Windows?', 'Ctrl + V', 'Ctrl + X', 'Ctrl + C', 'Ctrl + Z', 'C', 'Ctrl + C: sao chép; Ctrl + V: dán.', 'Bài giảng tuần 3', 'Có']];
    $e = [QT_E_COLS,
        [$prefix . '-GK1', 'Kiểm tra giữa kỳ – Tin học', 'Lớp DH25 – Học kỳ 1', 'GK1', 30, 30, '20/11/2026 07:30', '20/11/2026 09:00', 'Chính thức', 'Không', 'Không', 'Có', 'Có', 'Có', 'Có'],
        [$prefix . '-ON', 'Ôn tập – Tin học', '', 'GK1', '', 20, '', '', 'Ôn luyện', 'Có', 'Có', 'Có', 'Có', 'Có', 'Không']];
    $g = [['Cột', 'Trang', 'Bắt buộc', 'Cách ghi'],
        ['MaCau', 'CauHoi', 'Có', 'Mã câu do Thầy/Cô tự đặt, không trùng trong bộ của mình. Chỉ gồm chữ, số, dấu gạch. Ví dụ TH-001'],
        ['Bo', 'CauHoi', '', 'Năm hoặc tên bộ câu hỏi, ví dụ 2026'],
        ['De', 'CauHoi', 'Có', 'Nhóm đề mà câu thuộc về, nhiều nhóm cách nhau bởi dấu phẩy. Ví dụ: GK1, CK. Đề thi sẽ lấy câu theo nhóm này'],
        ['Mang', 'CauHoi', '', 'Mảng / chương nội dung, dùng để thống kê'],
        ['MucDo', 'CauHoi', '', 'Dễ, Trung bình hoặc Khó'],
        ['CauHoi', 'CauHoi', 'Có', 'Nội dung câu hỏi'],
        ['A, B, C, D', 'CauHoi', 'Có', '4 phương án, không được trùng nhau'],
        ['DapAn', 'CauHoi', 'Có', 'Một chữ: A, B, C hoặc D'],
        ['GiaiThich', 'CauHoi', '', 'Hiện cho người thi khi đề cho xem đáp án'],
        ['CanCu', 'CauHoi', '', 'Nguồn: giáo trình, slide, trang...'],
        ['DangDung', 'CauHoi', '', 'Có / Không (để trống = Có). Câu "Không" sẽ không được đưa vào đề'],
        ['MaDe', 'DeThi', 'Có', 'Mã đề, không trùng trên toàn hệ thống. Ví dụ trong file đã dùng tiền tố riêng của Thầy/Cô (' . $prefix . '-...); nên giữ tiền tố này khi đặt mã mới'],
        ['TenDe, MoTa', 'DeThi', 'TenDe có', 'Tên và mô tả ngắn hiển thị cho người thi'],
        ['NhomCau', 'DeThi', 'Có', 'Lấy các câu có nhóm này ở cột De của trang CauHoi'],
        ['SoCau', 'DeThi', '', 'Để trống = lấy hết câu trong nhóm; điền số = bốc ngẫu nhiên từng ấy câu'],
        ['ThoiGianPhut', 'DeThi', 'Có', 'Thời gian làm bài (phút)'],
        ['MoLuc, DongLuc', 'DeThi', '', 'Khung giờ mở đề, dạng dd/mm/yyyy hh:mm. Để trống = không giới hạn'],
        ['CheDo', 'DeThi', '', 'Thi thử, Chính thức hoặc Ôn luyện'],
        ['HienDapAn, ChoLamLai, TronCau, TronPhuongAn, DangMo, ChiVaoBangLink', 'DeThi', '', 'Có / Không'],
        ['', '', '', ''],
        ['Lưu ý', '', '', 'Không đổi tên trang (CauHoi, DeThi) và dòng tiêu đề. Có thể xóa các dòng ví dụ. Trang DeThi không bắt buộc: có thể chỉ nhập câu hỏi rồi tạo đề trên web.'],
        ['', '', '', 'Nhập lại câu có cùng MaCau sẽ cập nhật câu cũ. Nếu tệp có lỗi, hệ thống báo đúng dòng và không ghi gì.']];
    xlsx_write($file, ['CauHoi' => ['rows' => $q, 'widths' => [12, 8, 12, 24, 12, 50, 26, 26, 26, 26, 8, 36, 22, 10]],
        'DeThi' => ['rows' => $e, 'widths' => [12, 30, 24, 10, 8, 12, 17, 17, 12, 10, 10, 10, 12, 10, 14]],
        'HuongDan' => ['rows' => $g, 'widths' => [30, 10, 10, 100]]]);
}
