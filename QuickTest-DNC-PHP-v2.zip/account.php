<?php
/* Tài khoản của tôi: thông tin cá nhân, đổi mật khẩu, xin quyền giáo viên. */
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
$u = require_user_page();
$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    same_origin_or_die();
    $act = $_POST['act'] ?? '';
    if ($act === 'profile') {
        $name = clean_str($_POST['name'] ?? '', 120); $unit = clean_str($_POST['unit'] ?? '', 150);
        if (count(explode(' ', $name)) < 2) $err = 'Vui lòng nhập đầy đủ họ và tên.';
        else { q('UPDATE qt_users SET name = ?, unit = ? WHERE id = ?', [$name, $unit, $u['id']]); $msg = 'Đã lưu thông tin.'; }
    } elseif ($act === 'password') {
        $row = q1('SELECT pass_hash FROM qt_users WHERE id = ?', [$u['id']]);
        $old = (string)($_POST['old'] ?? ''); $new = (string)($_POST['new'] ?? ''); $new2 = (string)($_POST['new2'] ?? '');
        if (!empty($row['pass_hash']) && !password_verify($old, $row['pass_hash'])) $err = 'Mật khẩu hiện tại không đúng.';
        elseif (strlen($new) < 8) $err = 'Mật khẩu mới cần tối thiểu 8 ký tự.';
        elseif ($new !== $new2) $err = 'Hai lần nhập mật khẩu mới không khớp.';
        else { q('UPDATE qt_users SET pass_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $u['id']]); audit($u['email'], 'password_change'); $msg = 'Đã đổi mật khẩu.'; }
    } elseif ($act === 'teacher' && !$u['teacher'] && in_array($u['teacher_status'], ['none', 'rejected'], true)) {
        q("UPDATE qt_users SET teacher_status = 'pending' WHERE id = ?", [$u['id']]); audit($u['email'], 'teacher_request'); $msg = 'Đã gửi yêu cầu. Quản trị viên sẽ duyệt sớm.';
    }
    $u = user_view(q1('SELECT * FROM qt_users WHERE id = ?', [$u['id']]));
}
if (isset($_GET['welcome'])) $msg = 'Đăng ký thành công. Yêu cầu quyền giáo viên đang chờ quản trị viên duyệt; trong lúc chờ, Thầy/Cô vẫn dùng được tài khoản để vào thi.';

$status = $u['teacher'] ? '<span class="pill ok">' . h(role_label($u['role'])) . '</span>'
    : ['pending' => '<span class="pill wait">Đang chờ duyệt quyền giáo viên</span>', 'rejected' => '<span class="pill bad">Yêu cầu giáo viên chưa được chấp nhận</span>'][$u['teacher_status']] ?? '<span class="pill">Người dự thi</span>';
header('Content-Type: text/html; charset=utf-8');
?><!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tài khoản – QuickTest DNC</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Lexend:wght@600;700&display=swap">
<style>
:root{--ink:#122033;--muted:#5b6a7e;--line:#d8e0e8;--bg:#f2f5f8;--card:#fff;--brand:#0b5d7a;--field:#f7f9fb;--ok:#1f7a4d;--okbg:#e3f3ea;--err:#b3261e;--errbg:#fbe9e7;--wait:#8a5a00;--waitbg:#fbefd6}
@media (prefers-color-scheme:dark){:root{--ink:#e6edf4;--muted:#9cabbc;--line:#2b3b4e;--bg:#0c141e;--card:#131e2b;--brand:#4fb0d0;--field:#0f1925;--ok:#62c995;--okbg:#14301f;--err:#f39a8e;--errbg:#3b1d1a;--wait:#e7b14a;--waitbg:#3a2c10}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.5 "Be Vietnam Pro",system-ui,sans-serif}
.wrap{max-width:860px;margin:0 auto;padding:22px 16px 60px}.top{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:18px}
.logo{display:inline-block;background:var(--brand);color:#fff;border-radius:8px;padding:0 10px;margin-right:6px;font:700 20px Lexend,sans-serif}
h1{font:700 24px Lexend,sans-serif;margin:0}h2{font:700 19px Lexend,sans-serif;margin:0 0 12px}a{color:var(--brand)}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:720px){.grid{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px}
label{display:block;font-weight:600;font-size:14px;margin:10px 0 5px}input{width:100%;padding:11px 13px;border:1px solid var(--line);border-radius:10px;background:var(--field);color:var(--ink);font:inherit;font-size:16px}
.btn{margin-top:14px;padding:11px 18px;border:0;border-radius:10px;background:var(--brand);color:#fff;font-family:inherit;font-weight:600;font-size:16px;cursor:pointer}
.msg{padding:11px 13px;border-radius:10px;margin-bottom:14px}.msg.ok{background:var(--okbg);color:var(--ok)}.msg.err{background:var(--errbg);color:var(--err)}
.pill{display:inline-block;border-radius:999px;padding:3px 12px;font-size:14px;font-weight:600;background:var(--field);border:1px solid var(--line)}
.pill.ok{background:var(--okbg);color:var(--ok);border:0}.pill.wait{background:var(--waitbg);color:var(--wait);border:0}.pill.bad{background:var(--errbg);color:var(--err);border:0}
.kv{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:16px}.muted{color:var(--muted)}
</style></head><body><div class="wrap">
<div class="top"><h1><span class="logo">QuickTest DNC</span> Tài khoản</h1>
<div class="muted"><a href="index.php">Trang thi</a><?= $u['teacher'] ? ' · <a href="admin.php">Quản lý đề thi</a>' : '' ?> · <a href="auth.php?a=logout">Đăng xuất</a></div></div>
<?= $msg ? '<div class="msg ok">' . h($msg) . '</div>' : '' ?><?= $err ? '<div class="msg err">' . h($err) . '</div>' : '' ?>
<div class="card" style="margin-bottom:16px"><div class="kv"><span class="muted">Email</span><b><?= h($u['email']) ?></b><span class="muted">Vai trò</span><span><?= $status ?></span>
<span class="muted">Đăng nhập</span><span><?= $u['google'] ? 'Google' : '' ?><?= $u['google'] && $u['has_password'] ? ' · ' : '' ?><?= $u['has_password'] ? 'Email + mật khẩu' : '' ?></span></div>
<?php if (!$u['teacher'] && in_array($u['teacher_status'], ['none', 'rejected'], true)): ?>
<form method="post" style="margin-top:12px"><input type="hidden" name="act" value="teacher"><button class="btn" type="submit">Xin quyền giáo viên (ra đề)</button></form>
<?php endif; ?></div>
<div class="grid">
<form class="card" method="post"><h2>Thông tin cá nhân</h2><input type="hidden" name="act" value="profile">
<label for="nm">Họ và tên</label><input id="nm" name="name" value="<?= h($u['name']) ?>" required>
<label for="un">Đơn vị công tác / Lớp</label><input id="un" name="unit" value="<?= h($u['unit']) ?>">
<button class="btn" type="submit">Lưu thông tin</button></form>
<form class="card" method="post"><h2><?= $u['has_password'] ? 'Đổi mật khẩu' : 'Đặt mật khẩu' ?></h2><input type="hidden" name="act" value="password">
<?php if ($u['has_password']): ?><label for="o">Mật khẩu hiện tại</label><input id="o" name="old" type="password" autocomplete="current-password" required><?php else: ?>
<p class="muted" style="margin:0;font-size:15px">Tài khoản đang đăng nhập bằng Google. Có thể đặt thêm mật khẩu để đăng nhập bằng email.</p><?php endif; ?>
<label for="n1">Mật khẩu mới (tối thiểu 8 ký tự)</label><input id="n1" name="new" type="password" autocomplete="new-password" required>
<label for="n2">Nhập lại mật khẩu mới</label><input id="n2" name="new2" type="password" autocomplete="new-password" required>
<button class="btn" type="submit">Lưu mật khẩu</button></form>
</div></div></body></html>
