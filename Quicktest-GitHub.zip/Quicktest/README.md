# QuickTest DNC

Hệ thống thi trắc nghiệm trực tuyến nhiều môn – Trường Công nghệ số & Trí tuệ nhân tạo, Trường Đại học Nam Cần Thơ.

Phiên bản 2.0 chạy trên hosting **PHP 8 + MySQL/MariaDB**, không cần Composer hay Node.js.

## Tính năng
- Nhiều giáo viên: mỗi giáo viên chỉ thấy và quản lý câu hỏi, đề thi, kết quả của mình.
- Đăng ký bằng email + mật khẩu hoặc Google Workspace; giáo viên chờ quản trị viên duyệt.
- Nhập đề từ Excel theo file mẫu; xuất ngân hàng câu hỏi và kết quả ra Excel.
- Mỗi đề có link riêng và mã QR; chấm điểm tự động trên máy chủ; thống kê theo câu, đơn vị.

## Cài đặt nhanh
1. Tải mã nguồn lên thư mục gốc tên miền trên hosting.
2. Tạo CSDL MySQL, mở `https://<tên-miền>/install.php` và làm theo hướng dẫn.
3. Xóa `install.php` sau khi cài.

Hướng dẫn đầy đủ: [HUONG_DAN.md](HUONG_DAN.md) hoặc tệp Word `HuongDan_CaiDat_QuickTest-DNC-v2.docx`.

## Lưu ý bảo mật
Tệp `app/config.php` (sinh ra khi cài đặt) chứa mật khẩu CSDL và Google Client secret, đã được loại khỏi kho bằng `.gitignore`. Không đưa tệp này lên GitHub.

## Kiểm thử
Thư mục `tests/` chứa bộ kiểm thử tự động (Node.js), chạy trên một bản cài thử riêng – xem chú thích đầu mỗi tệp.
