'use strict';
/* Kiểm thử tải: N người cùng bắt đầu, rồi cùng nộp bài 100 câu trong cùng một thời điểm.
   Chạy (máy chủ ở AUTH_MODE=dev): node test/load.js 450 */
const BASE = process.env.BASE || 'http://localhost:8088';   // địa chỉ bản cài THỬ (chế độ dev)
const N = Number(process.argv[2] || 450);
const CODE = process.env.CODE || 'TT1-2026';
const KEY = process.env.KEY || '';   // mã link của đề (phần sau ?k= trong link đề), bắt buộc vì người thi chỉ vào đề bằng link/QR

async function login(i) {
  // Mỗi người thi một tài khoản (đăng ký lần đầu, các lần sau đăng nhập)
  const email = `load${i}@example.com`, pw = 'Matkhau123';
  const post = (url, data) => fetch(BASE + url, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(data) });
  let r = await post('/auth.php?a=register', { name: 'Người Thi ' + i, email, unit: 'Đơn vị ' + (i % 20), password: pw, password2: pw, role: 'student' });
  if (r.status !== 302) r = await post('/auth.php?a=login', { email, password: pw });
  const jar = {}; (r.headers.getSetCookie() || []).forEach((x) => { const kv = x.split(';')[0]; const k = kv.indexOf('='); jar[kv.slice(0, k)] = kv.slice(k + 1); });
  return Object.entries(jar).map(([k, v]) => k + '=' + v).join('; ');
}
async function api(cookie, body) {
  const t = performance.now();
  const r = await fetch(BASE + '/api.php', { method: 'POST', headers: { 'Content-Type': 'text/plain', Cookie: cookie }, body: JSON.stringify(body) });
  const j = await r.json();
  return { ms: performance.now() - t, ok: r.ok && j.ok, j };
}
function stats(name, arr, wall) {
  const ms = arr.map((x) => x.ms).sort((a, b) => a - b);
  const q = (p) => Math.round(ms[Math.min(ms.length - 1, Math.floor(p * ms.length))]);
  console.log(`${name}: ${arr.filter((x) => x.ok).length}/${arr.length} thành công · trung vị ${q(0.5)} ms · p95 ${q(0.95)} ms · chậm nhất ${q(1)} ms · tổng ${Math.round(wall)} ms`);
}

(async () => {
  const cookies = []; for (let i = 0; i < N; i += 50) cookies.push(...await Promise.all(Array.from({ length: Math.min(50, N - i) }, (_, k) => login(i + k))));
  let t = performance.now();
  const starts = await Promise.all(cookies.map((c, i) => api(c, { action: 'start', code: CODE, name: 'Người thi ' + i, unit: 'Đơn vị ' + (i % 20), role: 'Giảng viên', key: KEY })));
  stats(`Bắt đầu đồng loạt (${N} người)`, starts, performance.now() - t);
  t = performance.now();
  const subs = await Promise.all(starts.map((s, i) => {
    const ans = {}; s.j.attempt.ids.forEach((id, k) => { ans[id] = (k + i) % 4; });
    return api(cookies[i], { action: 'submit', token: s.j.token, attempt: s.j.attempt, answers: ans, auto: true });
  }));
  stats(`Nộp đồng loạt (${N} bài × 100 câu)`, subs, performance.now() - t);
  const bad = subs.filter((x) => !x.ok);
  if (bad.length) console.log('Lỗi mẫu:', bad.slice(0, 3).map((x) => x.j));
  process.exit(bad.length || starts.some((x) => !x.ok) ? 1 : 0);
})();
