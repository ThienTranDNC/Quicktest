'use strict';
/* Kiểm thử đầu-cuối qua HTTP. Chạy: node test/api.test.js (máy chủ phải chạy ở AUTH_MODE=dev, BASE tại biến môi trường BASE). */
const assert = require('assert');
const path = require('path');
const ExcelJS = require('exceljs');
const { execFileSync } = require('child_process');
const BASE = process.env.BASE || 'http://localhost:8088';
// Lớp giả lập giao diện better-sqlite3 trên MySQL (đủ cho kiểm thử)
function sqlv(v) { return typeof v === 'number' ? String(v) : "'" + String(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'"; }
function runSql(sql) {
  const out = execFileSync('mysql', [...(process.env.MYSQL_ARGS || '-uqt -pqtpass').split(' '), 'quicktest', '--default-character-set=utf8mb4', '-B', '-e', sql], { encoding: 'utf8' });
  const lines = out.split('\n').filter((l) => l.length);
  if (!lines.length) return [];
  const head = lines[0].split('\t');
  return lines.slice(1).map((l) => { const c = l.split('\t'); const o = {}; head.forEach((h, i) => { const v = c[i]; o[h] = v === 'NULL' ? null : (/^-?\d+(\.\d+)?$/.test(v) ? Number(v) : v); }); return o; });
}
const DB = { prepare(sql) {
  const bind = (args) => { let i = 0; return sql.replace(/\?/g, () => sqlv(args[i++])); };
  return { get: (...a) => runSql(bind(a))[0], all: (...a) => runSql(bind(a)), run: (...a) => runSql(bind(a)) };
} };

function form(url, data) { return fetch(BASE + url, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(data) }); }
const ADMIN_PW = process.env.ADMIN_PW || 'TestAdmin-Pass1';
/** Đăng ký (người dự thi) nếu chưa có tài khoản, rồi đăng nhập bằng mật khẩu. */
async function login(email, name, pw) {
  pw = pw || (email === 'tranvanthien@nctu.edu.vn' ? ADMIN_PW : 'Matkhau123');
  let r = await form('/auth.php?a=register', { name, email, unit: 'Khoa Dược', password: pw, password2: pw, role: 'student', next: 'index.php' });
  if (r.status !== 302) r = await form('/auth.php?a=login', { email, password: pw, next: 'index.php' });
  assert.strictEqual(r.status, 302, 'login ' + email);
  const jar = {}; (r.headers.getSetCookie() || []).forEach((x) => { const kv = x.split(';')[0]; const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); });
  const c = Object.entries(jar).filter(([, v]) => v && v !== 'deleted').map(([k, v]) => k + '=' + v).join('; ');
  return c;
}
/** Mã link của đề (người thi chỉ vào được đề bằng link/QR). */
function keyOf(code) { const r = DB.prepare('SELECT access_key FROM qt_exams WHERE code = ?').get(code); return r ? r.access_key : ''; }
async function api(cookie, body, extra) {
  // Bắt đầu thi luôn cần mã link; tự gắn mã đúng nếu kiểm thử không chỉ định
  if (body && body.action === 'start' && !('key' in body)) body = Object.assign({}, body, { key: keyOf(body.code) });
  const r = await fetch(BASE + '/api.php', { method: 'POST', headers: Object.assign({ 'Content-Type': 'text/plain;charset=utf-8', Cookie: cookie }, extra || {}), body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() };
}
async function admin(cookie, method, url, body) {
  const r = await fetch(BASE + '/admin_api.php?r=' + encodeURIComponent(url.split('?')[0]) + (url.includes('?') ? '&' + url.split('?')[1] : ''), { method, headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, body: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
}
const key = () => { const m = {}; for (const q of DB.prepare('SELECT id, answer FROM qt_questions').all()) m[q.id] = 'ABCD'.indexOf(q.answer); return m; };
let passed = 0;
const ok = (name) => { passed++; console.log('  ✓ ' + name); };

(async () => {
  const U = await login('nguyenvana@nctu.edu.vn', 'Nguyễn Văn A');
  const U2 = await login('tranthib@nctu.edu.vn', 'Trần Thị B');
  const A = await login('tranvanthien@nctu.edu.vn', 'Trần Văn Thiện');
  assert(U && A);

  // Đăng nhập
  let r = await form('/auth.php?a=login', { email: 'tranvanthien@nctu.edu.vn', password: 'sai-mat-khau' });
  assert.strictEqual(r.status, 200);
  assert((await r.text()).includes('Email hoặc mật khẩu không đúng'));
  r = await form('/auth.php?a=register', { name: 'Ai Đó', email: 'nguyenvana@nctu.edu.vn', password: 'Matkhau123', password2: 'Matkhau123', role: 'student' });
  assert((await r.text()).includes('đã có tài khoản'));
  r = await form('/auth.php?a=register', { name: 'Ngắn', email: 'x@gmail.com', password: '123', password2: '123', role: 'student' });
  assert((await r.text()).includes('họ và tên'));
  ok('đăng nhập sai mật khẩu, đăng ký trùng email, thiếu họ tên: đều bị từ chối');
  r = await api('', { action: 'exams' });
  assert.strictEqual(r.status, 401);
  ok('API yêu cầu đăng nhập (401)');

  // Danh sách đề
  r = await api(U, { action: 'exams' });
  assert(r.body.ok && r.body.email === 'nguyenvana@nctu.edu.vn');
  assert.deepStrictEqual(r.body.exams, []);
  assert.strictEqual(r.body.needLink, true);
  ok('trang thi không liệt kê đề khi không có link/QR');
  r = await api(U, { action: 'exams', key: keyOf('TT1-2026') });
  assert.deepStrictEqual(r.body.exams.map((x) => x.code), ['TT1-2026']);
  assert(r.body.focus === 'TT1-2026' && r.body.exams.every((x) => x.count === 100 && x.minutes === 45));
  r = await api(U, { action: 'exams', key: keyOf('CT-2026') });
  assert(r.body.exams.length === 0 && /hiện không mở|chưa đến giờ/.test(r.body.linkNote), JSON.stringify(r.body.linkNote));
  r = await api(U, { action: 'start', code: 'TT1-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên', key: '' });
  assert(!r.body.ok && /đường link/.test(r.body.error));
  r = await api(U, { action: 'start', code: 'TT1-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên', key: keyOf('TT2-2026') });
  assert(!r.body.ok && /đường link/.test(r.body.error));
  ok('link của đề nào chỉ hiện đúng đề đó (100 câu, 45 phút); đề đang tắt báo không mở; không có link hoặc link đề khác thì không bắt đầu được');

  // Bắt đầu
  r = await api(U, { action: 'start', code: 'TT1-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên' });
  assert(r.body.ok && r.body.questions.length === 100);
  assert(r.body.questions.every((q) => !('a' in q) && !('answer' in q) && !('e' in q)));
  assert(!JSON.stringify(r.body).includes('"answer"'));
  ok('phát đề 100 câu, không lộ đáp án');
  const s1 = r.body;
  assert.strictEqual(DB.prepare('SELECT COUNT(*) n FROM qt_attempts WHERE id = ?').get(s1.attempt.id).n, 1);

  // Nộp đúng hết
  const K = key();
  const allRight = {}; s1.attempt.ids.forEach((id) => { allRight[id] = K[id]; });
  r = await api(U2, { action: 'submit', token: s1.token, attempt: s1.attempt, answers: allRight });
  assert(!r.body.ok && /tài khoản khác/.test(r.body.error));
  ok('tài khoản khác không nộp thay được');
  r = await api(U, { action: 'submit', token: 'x' + s1.token.slice(1), attempt: s1.attempt, answers: allRight });
  assert(!r.body.ok && /không hợp lệ/.test(r.body.error));
  ok('mã lượt bị sửa thì bị từ chối');
  r = await api(U, { action: 'submit', token: s1.token, attempt: s1.attempt, answers: allRight });
  assert(r.body.ok && r.body.score === 10 && r.body.correct === 100 && r.body.level === 'Tốt' && r.body.review.length === 100);
  ok('trả lời đúng hết: 10 điểm, xếp loại Tốt, có xem lại đáp án');
  const again = await api(U, { action: 'submit', token: s1.token, attempt: s1.attempt, answers: {} });
  assert(again.body.ok && again.body.score === 10);
  assert.strictEqual(DB.prepare('SELECT COUNT(*) n FROM qt_answers WHERE attempt_id = ?').get(s1.attempt.id).n, 100);
  ok('nộp lặp lại: trả kết quả cũ, không ghi trùng');

  // Nộp một phần: 37 đúng, 10 sai, còn lại bỏ trống
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên' });
  const s2 = r.body; const part = {};
  s2.attempt.ids.forEach((id, i) => { if (i < 37) part[id] = K[id]; else if (i < 47) part[id] = (K[id] + 1) % 4; });
  r = await api(U, { action: 'submit', token: s2.token, attempt: s2.attempt, answers: part, auto: true });
  assert(r.body.score === 3.7 && r.body.correct === 37 && r.body.answered === 47 && r.body.level === 'Chưa đạt');
  const row = DB.prepare('SELECT * FROM qt_attempts WHERE id = ?').get(s2.attempt.id);
  assert(row.auto_ === 1 && row.score === 3.7);
  ok('chấm đúng bài làm một phần: 37 đúng → 3,7 điểm, ghi nhận tự nộp');

  // Quản trị: quyền
  r = await admin(U, 'GET', '/overview');
  assert.strictEqual(r.status, 403);
  ok('người thi không vào được API quản trị');
  r = await fetch(BASE + '/admin_api.php?r=%2Fsettings', { method: 'PUT', headers: { 'Content-Type': 'application/json', Cookie: A, Origin: 'https://evil.example' }, body: '{}' });
  assert.strictEqual(r.status, 403);
  r = await api(U, { action: 'exams' }, { Origin: 'https://evil.example' });
  assert.strictEqual(r.status, 403);
  ok('chặn yêu cầu ghi từ trang web khác nguồn');

  // Quản trị: cấu hình đề chính thức
  r = await admin(A, 'PUT', '/exams/CT-2026', { name: 'Đề chính thức', desc: 'Kỳ thi 2026', group: 'CT', count: 100, minutes: 45, mode: 'Chính thức',
    active: true, showAnswers: false, retake: false, shuffleQ: true, shuffleOpts: true, openAt: new Date(Date.now() - 60e3).toISOString(), closeAt: new Date(Date.now() + 3600e3).toISOString() });
  assert(r.body.ok, JSON.stringify(r.body));
  r = await admin(A, 'PUT', '/exams/CT-2026', { name: 'x', group: 'CT', minutes: 45, openAt: '2026-10-20T08:00:00Z', closeAt: '2026-10-20T07:00:00Z' });
  assert(!r.body.ok && /sau giờ mở/.test(r.body.error));
  r = await admin(A, 'PUT', '/exams/CT-2026', { name: 'x', group: 'CT', minutes: 0 });
  assert(!r.body.ok);
  ok('sửa cấu hình đề (khung giờ, hình thức, xem đáp án, làm lại) và kiểm tra dữ liệu nhập');

  r = await api(U2, { action: 'exams', key: keyOf('CT-2026') });
  assert(r.body.exams.some((x) => x.code === 'CT-2026' && x.count === 100 && x.mode === 'Chính thức'));
  const c1 = await api(U2, { action: 'start', code: 'CT-2026', name: 'Trần Thị B', unit: 'Phòng Đào tạo', role: 'Cán bộ, nhân viên' });
  const c2 = await api(U2, { action: 'start', code: 'CT-2026', name: 'Trần Thị B', unit: 'Phòng Đào tạo', role: 'Cán bộ, nhân viên' });
  assert(c2.body.resumed && c2.body.attempt.id === c1.body.attempt.id);
  assert.deepStrictEqual(c2.body.attempt.ids, c1.body.attempt.ids);
  assert(c2.body.remainingSec <= 45 * 60 && c2.body.remainingSec > 44 * 60);
  ok('đề chính thức: bắt đầu lại trả đúng lượt cũ (cùng câu, đồng hồ không reset)');
  const cAns = {}; c1.body.attempt.ids.forEach((id, i) => { cAns[id] = i % 2 ? K[id] : null; });
  r = await api(U2, { action: 'submit', token: c1.body.token, attempt: c1.body.attempt, answers: cAns });
  assert(r.body.ok && r.body.score === 5 && !r.body.review && r.body.showReview === false);
  ok('đề chính thức: chỉ trả điểm, không trả đáp án');
  r = await api(U2, { action: 'start', code: 'CT-2026', name: 'Trần Thị B', unit: 'Phòng Đào tạo', role: 'x' });
  assert(!r.body.ok && /đã nộp bài/.test(r.body.error));
  r = await api(U2, { action: 'exams', key: keyOf('CT-2026') });
  assert(r.body.exams.find((x) => x.code === 'CT-2026').done === true);
  ok('đề chính thức: mỗi tài khoản nộp một lần');

  // Nộp quá hạn
  r = await api(U, { action: 'start', code: 'TT1-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên' });
  DB.prepare('UPDATE qt_attempts SET started_at = started_at - ? WHERE id = ?').run((45 * 60 + 200) * 1000, r.body.attempt.id);
  const late = await api(U, { action: 'submit', token: r.body.token, attempt: r.body.attempt, answers: allRight });
  assert(late.body.ok && late.body.late === true && late.body.score === 0 && late.body.durationSec === 45 * 60);
  ok('nộp quá thời gian cho phép: ghi nhận, không tính điểm');

  // Đề đóng
  await admin(A, 'PUT', '/exams/TT2-2026', { name: 'Đề thi thử số 2', group: 'TT2', minutes: 45, active: false, retake: true, showAnswers: true, shuffleQ: true, shuffleOpts: true });
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên' });
  assert(!r.body.ok && /không mở/.test(r.body.error));
  ok('đề đã tắt thì không bắt đầu được');

  // Số câu bốc ngẫu nhiên
  await admin(A, 'PUT', '/exams/TT2-2026', { name: 'Đề thi thử số 2', group: 'TT2', count: 30, minutes: 15, active: true, retake: true, showAnswers: true, shuffleQ: true, shuffleOpts: true });
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên' });
  assert(r.body.questions.length === 30 && r.body.exam.minutes === 15 && new Set(r.body.attempt.ids).size === 30);
  r = await api(U, { action: 'submit', token: r.body.token, attempt: r.body.attempt, answers: {} });
  assert(r.body.total === 30 && r.body.score === 0);
  ok('đổi số câu (bốc 30/100) và thời gian (15 phút) có hiệu lực ngay');

  // Câu hỏi
  r = await admin(A, 'GET', '/questions?group=TT1');
  assert(r.body.questions.length === 100);
  const q0 = r.body.questions[0];
  r = await admin(A, 'PUT', '/questions/' + q0.id, Object.assign({}, q0, { explain: 'Giải thích thử' }));
  assert(r.body.ok);
  r = await admin(A, 'POST', '/questions', { id: 'TEST-01', groups: 'TT1', text: 'Câu thử?', opt_a: '1', opt_b: '2', opt_c: '3', opt_d: '4', answer: 'E', active: true });
  assert(!r.body.ok);
  r = await admin(A, 'POST', '/questions', { id: 'TEST-01', groups: 'X9', text: 'Câu thử?', opt_a: '1', opt_b: '2', opt_c: '3', opt_d: '4', answer: 'B', active: true });
  assert(r.body.ok);
  r = await admin(A, 'DELETE', '/questions/TEST-01');
  assert(r.body.ok);
  r = await admin(A, 'DELETE', '/questions/' + q0.id);
  assert(!r.body.ok && /không xóa được/.test(r.body.error));
  ok('thêm / sửa / xóa câu hỏi; không xóa được câu đã có người làm');

  // Xuất rồi nhập lại ngân hàng
  r = await admin(A, 'GET', '/export/bank.xlsx');
  assert(Buffer.isBuffer(r.body) && r.body.length > 10000);
  const bankBuf = r.body;
  let res2 = await fetch(BASE + '/admin_api.php?r=%2Fimport', { method: 'POST', headers: { Cookie: A, 'Content-Type': 'application/octet-stream' }, body: bankBuf });
  let imp = await res2.json();
  assert(imp.ok && imp.questions === 200 && imp.added === 0 && imp.exams === 3, JSON.stringify(imp));
  const e2 = DB.prepare("SELECT * FROM qt_exams WHERE code = 'CT-2026'").get();
  assert(e2.open_at && e2.close_at && e2.retake === 0 && e2.show_answers === 0);
  ok('xuất Excel ngân hàng rồi nhập lại: giữ nguyên 200 câu, 3 đề, khung giờ');

  // Nhập tệp lỗi
  const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet('CauHoi');
  ws.addRow(['MaCau', 'Bo', 'De', 'Mang', 'MucDo', 'CauHoi', 'A', 'B', 'C', 'D', 'DapAn']);
  ws.addRow(['N1', '2027', 'TT9', 'M', 'Dễ', 'Hỏi?', 'a', 'b', 'c', 'd', 'B']);
  ws.addRow(['N2', '2027', 'TT9', 'M', 'Dễ', 'Hỏi 2?', 'a', 'a', 'c', 'd', 'Z']);
  res2 = await fetch(BASE + '/admin_api.php?r=%2Fimport', { method: 'POST', headers: { Cookie: A }, body: Buffer.from(await wb.xlsx.writeBuffer()) });
  imp = await res2.json();
  assert(!imp.ok && imp.errors.length === 1 && imp.errors[0].row === 3 && /trùng/.test(imp.errors[0].error));
  assert(!DB.prepare("SELECT 1 FROM qt_questions WHERE id = 'N1'").get());
  ok('nhập tệp có lỗi: báo đúng dòng, không ghi gì');

  // Kết quả, thống kê, xuất Excel
  r = await admin(A, 'GET', '/results');
  assert(r.body.results.length === 5);
  r = await admin(A, 'GET', '/results/' + s2.attempt.id);
  assert(r.body.answers.length === 100 && r.body.answers[0].text);
  r = await admin(A, 'GET', '/stats?code=TT1-2026');
  assert(r.body.summary.n === 2 && r.body.perQuestion.length === 100);
  r = await admin(A, 'GET', '/export/results.xlsx');
  const wr = new ExcelJS.Workbook(); await wr.xlsx.load(r.body);
  assert(wr.getWorksheet('KetQua').rowCount === 6 && wr.getWorksheet('ChiTiet').rowCount === 1 + 100 + 100 + 100 + 100 + 30);
  ok('xem kết quả, chi tiết từng câu, thống kê; xuất Excel đủ 2 trang');

  r = await admin(A, 'GET', '/backup');
  assert(Buffer.isBuffer(r.body) && r.body.toString().includes('INSERT INTO `qt_questions`') && r.body.toString().includes('INSERT INTO `qt_attempts`'));
  ok('tải bản sao lưu cơ sở dữ liệu');

  // Đổi vai trò thành viên qua trang quản trị
  const ul = (await admin(A, 'GET', '/users')).body.users;
  const b = ul.find((u) => u.email === 'tranthib@nctu.edu.vn');
  r = await admin(A, 'PUT', '/users/' + b.id, { action: 'role', role: 'admin' });
  r = await admin(U2, 'GET', '/users');
  assert(r.status === 200 && r.body.ok);
  await admin(A, 'PUT', '/users/' + b.id, { action: 'role', role: 'student' });
  r = await admin(U2, 'GET', '/overview');
  assert.strictEqual(r.status, 403);
  ok('nâng / hạ vai trò thành viên');

  // Trang
  r = await fetch(BASE + '/', { headers: { Cookie: U } });
  assert(r.status === 200 && (await r.text()).includes('window.TESTAI_API_URL = "api.php"'));
  r = await fetch(BASE + '/admin.php', { redirect: 'manual', headers: { Cookie: U } });
  assert(r.status === 302 && r.headers.get('location') === 'account.php');
  r = await fetch(BASE + '/admin.php', { headers: { Cookie: A } });
  assert.strictEqual(r.status, 200);
  ok('trang thi và trang quản trị phân quyền đúng');

  // Link / mã QR riêng của đề
  r = await admin(A, 'PUT', '/exams/TT2-2026', { name: 'Đề thi thử số 2', group: 'TT2', count: 0, minutes: 45, active: true, retake: true, showAnswers: true, shuffleQ: true, shuffleOpts: true, unlisted: true });
  assert(r.body.ok);
  r = await admin(A, 'GET', '/overview');
  const tt2 = r.body.exams.find((x) => x.code === 'TT2-2026');
  assert(tt2.unlisted && /\/\?k=[\w-]{12}$/.test(tt2.link) && tt2.link.startsWith(BASE));
  const lk = tt2.key;
  r = await api(U, { action: 'exams' });
  assert(!r.body.exams.some((x) => x.code === 'TT2-2026'));
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên', key: '' });
  assert(!r.body.ok && /đường link/.test(r.body.error));
  ok('đề "chỉ vào bằng link": ẩn khỏi danh sách, không bắt đầu được nếu không có link');
  r = await api(U, { action: 'exams', key: lk });
  assert(r.body.focus === 'TT2-2026' && r.body.exams.some((x) => x.code === 'TT2-2026'));
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên', key: lk });
  assert(r.body.ok && r.body.questions.length === 100);
  ok('vào bằng link: đề hiện ra, được chọn sẵn và bắt đầu được');
  let rr = await fetch(BASE + '/d/' + lk, { redirect: 'manual' });
  assert(String(rr.headers.get('location')).endsWith('index.php?k=' + lk), 'htaccess /d/');
  rr = await fetch(BASE + '/?k=' + lk, { redirect: 'manual' });
  assert(rr.status === 302 && decodeURIComponent(rr.headers.get('location')).includes('next=index.php?k=' + lk));
  rr = await form('/auth.php?a=register', { email: 'moi@nctu.edu.vn', name: 'Người Mới', password: 'Matkhau123', password2: 'Matkhau123', role: 'student', next: 'index.php?k=' + lk });
  assert.strictEqual(rr.headers.get('location'), 'index.php?k=' + lk);
  ok('mở link khi chưa đăng nhập: đăng nhập xong quay lại đúng đề');
  r = await admin(A, 'GET', '/exams/TT2-2026/poster');
  const poster = r.body.toString();
  assert(poster.includes('assets/qrcode.js') && poster.includes('?k=' + lk) && poster.includes('Đề thi thử số 2'));
  r = await admin(U, 'GET', '/exams/TT2-2026/poster');
  assert.strictEqual(r.status, 403);
  ok('trang in mã QR A4 (QR vẽ trên trình duyệt); chỉ quản trị viên mở được');
  r = await admin(A, 'POST', '/exams/TT2-2026/rekey', {});
  assert(r.body.ok && !r.body.link.endsWith(lk));
  r = await api(U, { action: 'exams', key: lk });
  assert(!r.body.focus && /không hợp lệ/.test(r.body.linkNote));
  r = await api(U, { action: 'start', code: 'TT2-2026', name: 'Nguyễn Văn A', unit: 'Khoa Dược', role: 'Giảng viên', key: lk });
  assert(!r.body.ok);
  ok('đổi link mới: link và QR cũ hết hiệu lực');
  await admin(A, 'PUT', '/exams/CT-2026', { name: 'Đề chính thức', group: 'CT', minutes: 45, active: true, openAt: new Date(Date.now() + 3600e3).toISOString(), retake: false });
  const ctKey = (await admin(A, 'GET', '/overview')).body.exams.find((x) => x.code === 'CT-2026').key;
  r = await api(U, { action: 'exams', key: ctKey });
  assert(!r.body.focus && /chưa đến giờ mở/.test(r.body.linkNote));
  ok('mở link khi đề chưa đến giờ: báo giờ mở');
  r = await admin(A, 'GET', '/export/bank.xlsx');
  const wb3 = new ExcelJS.Workbook(); await wb3.xlsx.load(r.body);
  const de = wb3.getWorksheet('DeThi');
  assert(de.getRow(1).values.includes('ChiVaoBangLink'));
  res2 = await fetch(BASE + '/admin_api.php?r=%2Fimport', { method: 'POST', headers: { Cookie: A }, body: r.body });
  assert((await res2.json()).ok && DB.prepare("SELECT unlisted FROM qt_exams WHERE code = 'TT2-2026'").get().unlisted === 1);
  ok('cột "ChiVaoBangLink" trong Excel: xuất và nhập lại giữ nguyên');

  console.log(`\nĐẠT ${passed}/${passed} nhóm kiểm thử`);
})().catch((e) => { console.error('\nLỖI:', e); process.exit(1); });
