'use strict';
/* Kiểm thử đăng nhập Google của bản PHP: giả lập máy chủ token của Google ở cổng 9099.
   Yêu cầu app/config.php: auth_mode=google, google_client_id=cid-123..., google_token_url=http://127.0.0.1:9099/token */
const assert = require('assert');
const http = require('http');
const B = process.env.BASE || 'http://localhost:8088';
const CID = 'cid-123.apps.googleusercontent.com';
let nextClaims = null, lastReq = null;
const mock = http.createServer((req, res) => {
  let body = ''; req.on('data', (c) => (body += c)); req.on('end', () => {
    lastReq = new URLSearchParams(body);
    const b = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ id_token: b({ alg: 'RS256' }) + '.' + b(nextClaims) + '.sig' }));
  });
});
function jarOf(r, jar = {}) { (r.headers.getSetCookie() || []).forEach((x) => { const kv = x.split(';')[0]; const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }); return jar; }
const cookie = (jar) => Object.entries(jar).filter(([, v]) => v && v !== 'deleted').map(([k, v]) => k + '=' + v).join('; ');
async function flow(claimsFn) {
  const r1 = await fetch(B + '/auth.php?a=google&next=admin.php', { redirect: 'manual' });
  const loc = new URL(r1.headers.get('location'));
  assert.strictEqual(loc.origin + loc.pathname, 'https://accounts.google.com/o/oauth2/v2/auth');
  assert.strictEqual(loc.searchParams.get('hd'), 'nctu.edu.vn');
  assert.strictEqual(loc.searchParams.get('redirect_uri'), B + '/auth.php?a=callback');
  const jar = jarOf(r1);
  nextClaims = claimsFn(loc.searchParams.get('nonce'));
  const r2 = await fetch(B + '/auth.php?a=callback&code=abc&state=' + loc.searchParams.get('state'), { redirect: 'manual', headers: { Cookie: cookie(jar) } });
  jarOf(r2, jar);
  const body = r2.status === 200 ? await r2.text() : '';
  return { location: r2.headers.get('location') || (body.includes('class="msg err"') ? 'err=' : ''), cookie: cookie(jar) };
}
const base = (nonce, o) => Object.assign({ iss: 'https://accounts.google.com', aud: CID, exp: Math.floor(Date.now() / 1000) + 600, nonce,
  email: 'tranvanthien@nctu.edu.vn', email_verified: true, hd: 'nctu.edu.vn', name: 'Trần Văn Thiện' }, o || {});
const isAdminPage = async (c) => (await fetch(B + '/admin.php', { redirect: 'manual', headers: { Cookie: c } })).status;
mock.listen(9099, async () => {
  try {
    let r = await flow((n) => base(n));
    assert.strictEqual(r.location, 'admin.php');   // quản trị viên vào thẳng trang quản lý
    assert.strictEqual(lastReq.get('code'), 'abc');
    assert.strictEqual(await isAdminPage(r.cookie), 200);
    console.log('  ✓ tài khoản @nctu.edu.vn hợp lệ: đăng nhập được, vào trang quản trị');
    for (const [label, fn] of [['Gmail cá nhân', (n) => base(n, { email: 'x@gmail.com', hd: undefined })], ['miền khác', (n) => base(n, { email: 'x@other.edu.vn', hd: 'other.edu.vn' })],
      ['sai client', (n) => base(n, { aud: 'other' })], ['sai nonce', () => base('bad')], ['hết hạn', (n) => base(n, { exp: 1 })], ['email chưa xác minh', (n) => base(n, { email_verified: false })]]) {
      r = await flow(fn);
      assert(String(r.location).includes('err='), label);
      assert.strictEqual(await isAdminPage(r.cookie), 302, label);
    }
    console.log('  ✓ Gmail cá nhân, miền khác, sai client, sai nonce, hết hạn, email chưa xác minh: bị từ chối');
    const forged = await fetch(B + '/auth.php?a=callback&code=abc&state=forged', { redirect: 'manual' });
    assert((await forged.text()).includes('không hợp lệ'));
    console.log('  ✓ state giả mạo bị từ chối');
    r = await flow((n) => base(n, { email: 'gv@nctu.edu.vn' }));
    assert.strictEqual(r.location, 'admin.php');   // về trang được yêu cầu
    assert.strictEqual(await isAdminPage(r.cookie), 302);   // chưa phải giáo viên: chuyển sang trang tài khoản
    assert.strictEqual((await fetch(B + '/', { redirect: 'manual', headers: { Cookie: r.cookie } })).status, 200);
    console.log('  ✓ tài khoản @nctu mới: tự tạo tài khoản người dự thi, vào trang thi, chưa vào trang quản lý');
    const reg = await fetch(B + '/auth.php?a=register', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ name: 'Kẻ Mạo Danh', email: 'ai.do@nctu.edu.vn', password: 'Matkhau123', password2: 'Matkhau123', role: 'teacher' }) });
    assert((await reg.text()).includes('Đăng nhập bằng Google'));
    console.log('  ✓ khi bật Google, email @nctu.edu.vn không đăng ký bằng mật khẩu được (chống mạo danh)');
    const page = await (await fetch(B + '/auth.php?a=login')).text();
    assert(page.includes('Đăng nhập bằng Google'));
    console.log('  ✓ trang đăng nhập có nút Google');
    console.log('\nĐẠT toàn bộ kiểm thử đăng nhập Google (bản PHP)');
  } catch (e) { console.error('LỖI', e); process.exitCode = 1; }
  mock.close();
});
