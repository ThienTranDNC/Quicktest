'use strict';
/* Kiểm thử nhiều giáo viên: đăng ký, duyệt quyền, mỗi giáo viên chỉ thấy dữ liệu của mình, file mẫu, chống dò mật khẩu.
   Chạy sau khi cài mới (quản trị viên tranvanthien@nctu.edu.vn / ADMIN_PW). */
const assert = require('assert');
const ExcelJS = require('exceljs');
const BASE = process.env.BASE || 'http://localhost:8088';
const ADMIN_PW = process.env.ADMIN_PW || 'TestAdmin-Pass1';
let passed = 0;
const ok = (m) => { passed++; console.log('  ✓ ' + m); };
const uniq = Date.now().toString(36);

function jar(r, j = {}) { (r.headers.getSetCookie() || []).forEach((x) => { const kv = x.split(';')[0]; const i = kv.indexOf('='); j[kv.slice(0, i)] = kv.slice(i + 1); }); return j; }
const ck = (j) => Object.entries(j).filter(([, v]) => v && v !== 'deleted').map(([k, v]) => k + '=' + v).join('; ');
const form = (url, data, cookie) => fetch(BASE + url, { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(cookie ? { Cookie: cookie } : {}) }, body: new URLSearchParams(data) });
async function register(name, email, role, pw = 'Matkhau123') {
  const r = await form('/auth.php?a=register', { name, email, unit: 'Khoa CNTT', password: pw, password2: pw, role });
  return { r, cookie: ck(jar(r)) };
}
async function login(email, pw) { const r = await form('/auth.php?a=login', { email, password: pw }); return { r, cookie: ck(jar(r)) }; }
async function A(cookie, method, url, body, raw) {
  const [p, q] = url.split('?');
  const r = await fetch(BASE + '/admin_api.php?r=' + encodeURIComponent(p) + (q ? '&' + q : ''), { method, headers: { Cookie: cookie, ...(raw ? {} : { 'Content-Type': 'application/json' }) }, body: raw || (body === undefined ? undefined : JSON.stringify(body)) });
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, body: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
}
async function api(cookie, body) {
  const r = await fetch(BASE + '/api.php', { method: 'POST', headers: { Cookie: cookie, 'Content-Type': 'text/plain' }, body: JSON.stringify(body) });
  return r.json();
}
async function workbook(rows) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('CauHoi');
  ws.addRow(['MaCau', 'Bo', 'De', 'Mang', 'MucDo', 'CauHoi', 'A', 'B', 'C', 'D', 'DapAn', 'GiaiThich', 'CanCu', 'DangDung']);
  rows.q.forEach((x) => ws.addRow(x));
  if (rows.e) { const we = wb.addWorksheet('DeThi'); we.addRow(['MaDe', 'TenDe', 'MoTa', 'NhomCau', 'SoCau', 'ThoiGianPhut', 'MoLuc', 'DongLuc', 'CheDo', 'HienDapAn', 'ChoLamLai', 'TronCau', 'TronPhuongAn', 'DangMo']); rows.e.forEach((x) => we.addRow(x)); }
  return Buffer.from(await wb.xlsx.writeBuffer());
}

(async () => {
  const admin = (await login('tranvanthien@nctu.edu.vn', ADMIN_PW)).cookie;
  assert(admin);
  let r = await fetch(BASE + '/auth.php?a=login'); let html = await r.text();
  assert(html.includes('Đăng nhập') && html.includes('Đăng ký') && !html.includes('Đăng nhập bằng Google'));
  ok('trang đăng nhập / đăng ký hiển thị (chưa bật Google thì không hiện nút Google)');

  // --- Đăng ký giáo viên: chờ duyệt
  const t1mail = `gv1.${uniq}@gmail.com`, t2mail = `gv2.${uniq}@gmail.com`;
  let g1 = await register('Lê Văn Một', t1mail, 'teacher');
  assert.strictEqual(g1.r.headers.get('location'), 'account.php?welcome=1');
  r = await fetch(BASE + '/admin.php', { redirect: 'manual', headers: { Cookie: g1.cookie } });
  assert.strictEqual(r.headers.get('location'), 'account.php');
  assert.strictEqual((await A(g1.cookie, 'GET', '/overview')).status, 403);
  html = await (await fetch(BASE + '/account.php', { headers: { Cookie: g1.cookie } })).text();
  assert(html.includes('Đang chờ duyệt quyền giáo viên'));
  ok('đăng ký vai trò giáo viên: chưa được vào trang quản lý, trang tài khoản báo "đang chờ duyệt"');

  let g2 = await register('Phạm Thị Hai', t2mail, 'teacher');
  let users = (await A(admin, 'GET', '/users')).body.users;
  const u1 = users.find((u) => u.email === t1mail), u2 = users.find((u) => u.email === t2mail);
  assert(u1.teacher_status === 'pending' && u1.role === 'student');
  assert((await A(admin, 'GET', '/me')).body.pendingTeachers >= 2);
  await A(admin, 'PUT', '/users/' + u1.id, { action: 'approve' });
  await A(admin, 'PUT', '/users/' + u2.id, { action: 'approve' });
  r = await A(g1.cookie, 'GET', '/me');
  assert(r.status === 200 && r.body.user.role === 'teacher' && r.body.user.teacher === true);
  assert.strictEqual((await A(g1.cookie, 'GET', '/users')).status, 403);
  assert.strictEqual((await A(g1.cookie, 'GET', '/settings')).status, 403);
  assert.strictEqual((await A(g1.cookie, 'GET', '/backup')).status, 403);
  ok('quản trị viên duyệt → thành giáo viên; giáo viên không vào được Thành viên, Cài đặt, Sao lưu');

  // --- File mẫu
  r = await A(g1.cookie, 'GET', '/template.xlsx');
  const tw = new ExcelJS.Workbook(); await tw.xlsx.load(r.body);
  assert(tw.getWorksheet('CauHoi') && tw.getWorksheet('DeThi') && tw.getWorksheet('HuongDan'));
  assert.strictEqual(tw.getWorksheet('CauHoi').getRow(1).getCell(1).value, 'MaCau');
  r = await A(g1.cookie, 'POST', '/import', undefined, r.body);
  assert(r.body.ok && r.body.questions === 3 && r.body.exams === 2, JSON.stringify(r.body));
  ok('tải file mẫu (3 trang: CauHoi, DeThi, HuongDan) và nhập lại ngay được: 3 câu, 2 đề');

  // --- Hai giáo viên dùng trùng mã câu; mã đề không được trùng
  const qrows = (prefix, ans) => [1, 2, 3, 4].map((i) => [`C${i}`, '2026', 'G1', 'Mảng ' + prefix, 'Dễ', `${prefix} câu ${i}?`, 'Một', 'Hai', 'Ba', 'Bốn', ans, '', '', 'Có']);
  r = await A(g1.cookie, 'POST', '/import', undefined, await workbook({ q: qrows('GV1', 'A'), e: [[`E1-${uniq}`, 'Đề GV1', '', 'G1', '', 10, '', '', 'Thi thử', 'Có', 'Có', 'Có', 'Không', 'Có']] }));
  assert(r.body.ok, JSON.stringify(r.body));
  r = await A(g2.cookie, 'POST', '/import', undefined, await workbook({ q: qrows('GV2', 'D'), e: [[`E2-${uniq}`, 'Đề GV2', '', 'G1', '', 10, '', '', 'Thi thử', 'Có', 'Có', 'Có', 'Không', 'Có']] }));
  assert(r.body.ok && r.body.added === 4, JSON.stringify(r.body));
  r = await A(g2.cookie, 'POST', '/import', undefined, await workbook({ q: qrows('GV2', 'D'), e: [[`E1-${uniq}`, 'Cướp mã', '', 'G1', '', 10, '', '', 'Thi thử', 'Có', 'Có', 'Có', 'Không', 'Có']] }));
  assert(!r.body.ok && /giáo viên khác/.test(r.body.errors[0].error));
  r = await A(g2.cookie, 'PUT', `/exams/E1-${uniq}`, { name: 'x', group: 'G1', minutes: 5 });
  assert(!r.body.ok && /giáo viên khác/.test(r.body.error));
  ok('hai giáo viên cùng đặt mã câu C1..C4 không đụng nhau; mã đề của người khác thì bị chặn (nhập Excel lẫn sửa trên web)');

  // --- Mỗi giáo viên chỉ thấy của mình
  const o1 = (await A(g1.cookie, 'GET', '/overview')).body, o2 = (await A(g2.cookie, 'GET', '/overview')).body;
  assert(o1.exams.every((x) => x.owner === t1mail) && o1.exams.length === 3);
  assert(o2.exams.every((x) => x.owner === t2mail) && o2.exams.length === 1);
  const q1 = (await A(g1.cookie, 'GET', '/questions')).body.questions, q2 = (await A(g2.cookie, 'GET', '/questions')).body.questions;
  assert(q1.length === 7 && q1.every((q) => q.owner === t1mail));
  assert(q2.length === 4 && q2.every((q) => q.owner === t2mail && q.text.startsWith('GV2')));
  r = await A(g1.cookie, 'GET', '/questions?owner=' + encodeURIComponent(t2mail));
  assert(r.body.questions.every((q) => q.owner === t1mail));
  r = await A(g2.cookie, 'DELETE', `/exams/E1-${uniq}`);
  assert.strictEqual(r.status, 404);
  r = await A(g2.cookie, 'GET', `/exams/E1-${uniq}/poster`);
  assert.strictEqual(r.status, 404);
  r = await A(g2.cookie, 'POST', `/exams/E1-${uniq}/rekey`, {});
  assert.strictEqual(r.status, 404);
  // TH-001 chỉ có trong ngân hàng GV1 (nhập từ file mẫu): GV2 gửi kèm owner=GV1 cũng không sửa / xóa được
  r = await A(g2.cookie, 'PUT', '/questions/TH-001?owner=' + encodeURIComponent(t1mail), { owner: t1mail, groups: 'G1', text: 'Sửa trộm', opt_a: '1', opt_b: '2', opt_c: '3', opt_d: '4', answer: 'A', active: true });
  assert.strictEqual(r.status, 404);
  assert.strictEqual((await A(g2.cookie, 'DELETE', '/questions/TH-001?owner=' + encodeURIComponent(t1mail))).status, 404);
  r = await A(g1.cookie, 'GET', '/questions?q=TH-001');
  assert(r.body.questions.find((q) => q.id === 'TH-001').text.startsWith('Thiết bị nào'));
  r = await A(g1.cookie, 'GET', '/export/bank.xlsx');
  const bw = new ExcelJS.Workbook(); await bw.xlsx.load(r.body);
  assert.strictEqual(bw.getWorksheet('CauHoi').rowCount, 8);
  ok('giáo viên chỉ thấy đề, câu hỏi của mình; không xóa / in QR / đổi link / sửa câu của người khác; xuất Excel chỉ có câu của mình');

  // --- Người thi làm đề của cả hai; chấm đúng theo ngân hàng của từng giáo viên
  const st = (await register('Sinh Viên Ba', `sv.${uniq}@gmail.com`, 'student')).cookie;
  const keys = Object.fromEntries((await A(admin, 'GET', '/overview')).body.exams.map((x) => [x.code, x.key]));
  let ex = await api(st, { action: 'exams' });
  assert(ex.exams.length === 0 && ex.needLink === true);
  for (const c of [`E1-${uniq}`, `E2-${uniq}`]) { const e = await api(st, { action: 'exams', key: keys[c] }); assert(e.exams.length === 1 && e.exams[0].code === c); }
  assert(ex.unit === 'Khoa CNTT' && ex.displayName === 'Sinh Viên Ba');
  for (const [code, right] of [[`E1-${uniq}`, 0], [`E2-${uniq}`, 3]]) {
    const s = await api(st, { action: 'start', code, name: 'Sinh Viên Ba', unit: 'Khoa CNTT', role: 'Sinh viên', key: keys[code] });
    assert(s.ok && s.questions.length === 4, JSON.stringify(s));
    const ans = {}; s.attempt.ids.forEach((id) => { ans[id] = right; });
    const res = await api(st, { action: 'submit', token: s.token, attempt: s.attempt, answers: ans });
    assert(res.ok && res.score === 10, code + ' ' + JSON.stringify(res));
  }
  ok('người thi làm đề của hai giáo viên trùng mã câu: chấm đúng theo ngân hàng của từng người (10/10 cả hai)');

  const r1 = (await A(g1.cookie, 'GET', '/results')).body.results, r2 = (await A(g2.cookie, 'GET', '/results')).body.results;
  assert(r1.length === 1 && r1[0].code === `E1-${uniq}` && r2.length === 1 && r2[0].code === `E2-${uniq}`);
  assert.strictEqual((await A(g1.cookie, 'GET', '/results/' + r2[0].id)).status, 404);
  assert.strictEqual((await A(g1.cookie, 'DELETE', '/results/' + r2[0].id)).status, 404);
  const s1 = (await A(g1.cookie, 'GET', '/stats')).body;
  assert(s1.summary.n === 1 && s1.perQuestion.length === 4 && s1.perQuestion.every((p) => p.text && p.text.startsWith('GV1')));
  r = await A(g1.cookie, 'GET', '/export/results.xlsx');
  const rw = new ExcelJS.Workbook(); await rw.xlsx.load(r.body);
  assert(rw.getWorksheet('KetQua').rowCount === 2 && rw.getWorksheet('ChiTiet').rowCount === 5);
  r = await A(g1.cookie, 'GET', '/results/' + r1[0].id);
  assert(r.body.answers.every((a) => a.text.startsWith('GV1')));
  ok('kết quả, chi tiết bài làm, thống kê, xuất Excel: mỗi giáo viên chỉ có bài làm đề của mình');

  // --- Quản trị viên thấy tất cả và lọc theo giáo viên
  const all = (await A(admin, 'GET', '/overview')).body.exams;
  assert(all.some((x) => x.owner === t1mail) && all.some((x) => x.owner === t2mail) && all.some((x) => x.owner === 'tranvanthien@nctu.edu.vn'));
  const only2 = (await A(admin, 'GET', '/questions?owner=' + encodeURIComponent(t2mail))).body.questions;
  assert(only2.length === 4 && only2.every((q) => q.owner === t2mail));
  r = await A(admin, 'PUT', '/questions/C1?owner=' + encodeURIComponent(t2mail), { owner: t2mail, groups: 'G1', area: 'x', text: 'QTV sửa', opt_a: '1', opt_b: '2', opt_c: '3', opt_d: '4', answer: 'D', active: true });
  assert(r.body.ok);
  assert((await A(g2.cookie, 'GET', '/questions?q=QTV')).body.questions.length === 1);
  assert((await A(admin, 'GET', '/results')).body.results.length >= 2);
  ok('quản trị viên xem toàn hệ thống, lọc theo từng giáo viên, sửa giúp câu hỏi của giáo viên');

  // --- Khóa tài khoản, cấp lại mật khẩu
  r = await A(admin, 'PUT', '/users/' + u2.id, { action: 'deactivate' });
  assert.strictEqual((await A(g2.cookie, 'GET', '/overview')).status, 401);
  assert((await (await form('/auth.php?a=login', { email: t2mail, password: 'Matkhau123' })).text()).includes('bị khóa'));
  await A(admin, 'PUT', '/users/' + u2.id, { action: 'activate' });
  r = await A(admin, 'PUT', '/users/' + u2.id, { action: 'resetpw' });
  assert(r.body.tempPassword && r.body.tempPassword.length === 10);
  assert.strictEqual((await login(t2mail, 'Matkhau123')).r.status, 200);
  const relog = await login(t2mail, r.body.tempPassword);
  assert.strictEqual(relog.r.status, 302);
  r = await A(admin, 'PUT', '/users/1', { action: 'role', role: 'student' });
  assert(!r.body.ok);
  ok('khóa tài khoản đẩy người dùng ra ngay; mở khóa; cấp mật khẩu tạm; quản trị viên không tự hạ quyền mình');

  // --- Trang tài khoản: đổi mật khẩu
  let a = await form('/account.php', { act: 'password', old: r.body.tempPassword || 'x', new: 'Moi12345', new2: 'Moi12345' }, relog.cookie);
  const html2 = await a.text();
  assert(html2.includes('Mật khẩu hiện tại không đúng') || html2.includes('Đã đổi mật khẩu'));
  ok('trang tài khoản: kiểm tra mật khẩu cũ khi đổi mật khẩu');

  // --- Chống dò mật khẩu
  const victim = `dich.${uniq}@gmail.com`;
  await register('Người Bị Dò', victim, 'student', 'DungRoi123');
  for (let i = 0; i < 8; i++) await form('/auth.php?a=login', { email: victim, password: 'sai' + i });
  const blocked = await (await form('/auth.php?a=login', { email: victim, password: 'DungRoi123' })).text();
  assert(blocked.includes('quá nhiều lần'));
  ok('sai mật khẩu 8 lần: tạm khóa đăng nhập email đó 15 phút (kể cả khi sau đó nhập đúng)');

  // --- Đăng ký chặn chiếm email đã có
  r = await form('/auth.php?a=register', { name: 'Kẻ Mạo Danh', email: 'tranvanthien@nctu.edu.vn', password: 'Matkhau123', password2: 'Matkhau123', role: 'teacher' });
  assert((await r.text()).includes('đã có tài khoản'));
  ok('không đăng ký đè lên email đã có (kể cả email quản trị)');

  console.log(`\nĐẠT ${passed}/${passed} nhóm kiểm thử nhiều giáo viên`);
})().catch((e) => { console.error('\nLỖI:', e); process.exit(1); });
